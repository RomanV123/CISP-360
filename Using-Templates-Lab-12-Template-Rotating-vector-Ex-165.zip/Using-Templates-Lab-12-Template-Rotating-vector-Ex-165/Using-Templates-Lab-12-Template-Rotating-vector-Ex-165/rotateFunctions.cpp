// Function to rotate data by one index


//function to rotate data one to the left
void rotateLeft(vector <T> & v){
  //write this function
}

// Function to output data

void output(vector <T> v) {
  //enter code for this function
}
