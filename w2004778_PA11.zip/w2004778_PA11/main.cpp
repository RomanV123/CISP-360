//Roman Vasilyev


#include<memory>
#include "Dragon.h"
#include "Elf.h"
#include "Genie.h"
#include "Goblin.h"
#include<typeinfo>

void displayCreatures(const vector<shared_ptr<MagicalCreatures>>& creatures) {
    auto printDisplay = [](const shared_ptr<MagicalCreatures>& creature) {
        cout << "I am a : " << creature->getType() << endl;
        cout << "My color is : " << creature->getColor() << endl;
        cout << "My speech : " << creature->talk() << endl;
        cout << "My habitat: " << creature->liveIn() << endl;
        cout << "I am " << creature->getAge() << " years of age" << endl;
        cout << endl;
        cout << "Displaying the " << creature->getType() << " Object:" << endl;
        cout << creature->toString() << endl << endl;
    };

    for (const auto& creature : creatures) {
        printDisplay(creature);
    }
}


int main()
{
	//create a vector of pointer to MagicalCreatures
	vector<shared_ptr<MagicalCreatures>> creatures;

	//create the individual creatures of type pointer of MagicalCreatures
	shared_ptr<Dragon> dragon = make_shared< Dragon>("Jack","black","Dragon", 200, 500, true);
	shared_ptr<Elf> elf = make_shared<Elf>("Doug", "green", "Elf", 80);
	shared_ptr<Genie> genie = make_shared< Genie>("Cosmo", "blue", "Genie", 1000, 40, true);
	shared_ptr<Goblin> goblin = make_shared<Goblin>("Harry", "red", "Goblin", 150);

	//push back creatures to MagicalCreatures
 
	creatures.push_back(dragon);
	creatures.push_back(elf);
	creatures.push_back(genie);
	creatures.push_back(goblin);
  displayCreatures(creatures);
  
	}
