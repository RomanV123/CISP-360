#ifndef MagicalCreatures_h
#define MagicalCreatures_h
#include <string> 
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


class MagicalCreatures
{
private:
	
	string name;
	string color;
	string type;
    int age;

public:

  MagicalCreatures();

  MagicalCreatures(string name, string color, string type, int age);
 // talk method
  virtual string  talk();
 // live in function
  virtual string liveIn(); 

  virtual string toString();

  string getName();
  void setName(string name);
  string getColor();
  void setColor(string color);
  int getAge();
  void setAge(int age);
  string getType();
  void setType(string type);

 virtual ~MagicalCreatures() = default;
}; 

#endif