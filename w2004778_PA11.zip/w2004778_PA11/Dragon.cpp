#include "Dragon.h"
#include "MagicalCreatures.h"

Dragon::Dragon(): MagicalCreatures() {}

Dragon::Dragon(string name, string color, string type, int age, int size, bool hasSpikes): MagicalCreatures(name, color, type, age), hasSpikes(hasSpikes), size(size) {}

int Dragon::getSize() {
  return size;
}

void Dragon::changeSize(int newSize) {
  size = newSize;
}

bool Dragon::getHasSpikes() {
  return hasSpikes;
}

void Dragon::setHasSpikes(bool newHasSpikes) {
  this->hasSpikes = newHasSpikes;
}

string Dragon::toString() {
  return "I am a Dragon! I breathe fire!";
}

