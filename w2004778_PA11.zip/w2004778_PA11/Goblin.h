#ifndef Goblin_h
#define Goblin_h
#include "MagicalCreatures.h"
using namespace std;


class Goblin : public MagicalCreatures
{
public:
  Goblin(); //default constructor 
  Goblin(string name, string color, string type, int age);
  string talk() override; 
  

};

#endif