#ifndef Elf_h
#define Elf_h
#include "MagicalCreatures.h"
using namespace std;

//Elf Class
class Elf : public MagicalCreatures
{
//private:
  //int size; //weight in pounds of the dragon
//add fields from UML
public:
  Elf(); //default constructor 
  Elf(string name, string color, string type, int age);
  string toString() override;

};

#endif