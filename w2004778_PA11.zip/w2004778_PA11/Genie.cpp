#include "Genie.h"
#include "MagicalCreatures.h"

Genie::Genie(): MagicalCreatures() {}

Genie::Genie(string name, string color, string type, int age, int size, bool hasWand): MagicalCreatures(name, color, type, age), hasWand(hasWand), size(size) {}

string Genie::liveIn() {
  return "I live in a bottle";
}

int Genie::getSize() {
  return size;
}

int Genie::changeSize(int newSize) {
  if (newSize > 0) {
    size = newSize;
  }
  return size;
}

bool Genie::getHasWand() {
  return hasWand;
}

void Genie::setHasWand(bool hasWand){
  this->hasWand = hasWand;
}
