#include "Goblin.h"
#include "MagicalCreatures.h"

Goblin::Goblin(): MagicalCreatures() {}

Goblin::Goblin(string name, string color, string type, int age): MagicalCreatures(name, color, type, age) {}

string Goblin::talk() {
  return "I speak Gibberish";
}
