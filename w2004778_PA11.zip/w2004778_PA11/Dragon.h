#ifndef Dragon_h
#define Dragon_h
#include "MagicalCreatures.h"
using namespace std;

class Dragon : public MagicalCreatures
{
private:
  bool hasSpikes; //color of dragon
  int size; //weight in pounds of dragon
// add fields from UML

public:
  Dragon();
  Dragon(string name, string color, string type, int age, int size, bool hasSpikes);
  int getSize(); 
  void changeSize (int newSize); 
  bool getHasSpikes(); 
  void setHasSpikes(bool hasSpikes); 
  string toString() override; 
 // add functions from UML
};

#endif