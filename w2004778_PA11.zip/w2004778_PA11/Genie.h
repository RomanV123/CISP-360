#ifndef Genie_h
#define Genie_h
#include "MagicalCreatures.h"
using namespace std;

//Genie Class
class Genie : public MagicalCreatures
{
private:
  bool hasWand = true;
  int size;
//add fields from UML
public:
  Genie();
  Genie(string name, string color, string type, int age, int size, bool hasWand);
  string liveIn() override; //return "I live in a bottle"
  int getSize(); //returns size
  int changeSize(int newSize); //newSize must be >0
  bool getHasWand(); //return wand status
  void setHasWand(bool hasWand); 
//add function headers from UML
	};

#endif