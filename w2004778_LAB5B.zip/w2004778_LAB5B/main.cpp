//Roman Vasilyev 9/29/2023

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <stdexcept>
#include<cstdlib>
#include "Circle.h" // Assuming you have a Circle class definition



using namespace std;

const int SIZE = 10; // Define the size of the circlePointerArray
 // Create an array of pointers to circles
Circle* circlePointerArray[SIZE];
void print(int count);
void sum(int count);
void switch2();

 

// Function to read data from a file and populate the array of pointers
int inputData(Circle** circlePointerArray, string filename) {
    ifstream file(filename);
    istringstream instream;
    string data;

    if (!file.is_open()) {
        cerr << "File Open Error" << endl;
        exit(1); // Exit the program if the file cannot be opened
    }

    int count = 0;
    string line;
    while (getline(file, line) && count < SIZE) {
        istringstream instream(line);
        int x, y, radius;
        instream >> x >> y >> radius;
        circlePointerArray[count] = new Circle(x, y, radius);
        count++;
    }

    file.close();
    return count; // Return the number of circles created
}

int main() {
    // Declare two pointers to circles and create them using "new" memory
    Circle* One = new Circle(0, 0, 0);
    Circle* Two = new Circle(1, 1, 1);

    if (One->greaterThan(Two))
        cout << "Circle One is bigger" << endl;
    else
        cout << "Circle Two is bigger" << endl;

   

    // Populate the pointer array with circles from the data file
    int count = inputData(circlePointerArray, "C:/Users/roman/Downloads/dataLab5B.txt");
    std::cout << "The total number of circles is " << count << "\n";

    print(count);
    sum(count);
    switch2();
    print(count);


    

    

    return 0;
}

void print(int count) {

    for (int i = 0; i < count; i++) {

        std::cout << circlePointerArray[i]->toString() << endl;

    }

}

void sum(int count) {

    double sum = 0;

    for (int i = 0; i < count; i++) {
        sum += circlePointerArray[i]->getArea();

    }

    std::cout << "The total sum of the areas is " << sum << "\n";

}

void switch2() {

    Circle* temp;

    temp = circlePointerArray[1];
    circlePointerArray[1] = circlePointerArray[3];
    circlePointerArray[3] = temp;

}
