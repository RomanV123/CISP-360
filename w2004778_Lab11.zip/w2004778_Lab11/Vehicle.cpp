#include "Vehicle.h"

Vehicle:: Vehicle(){
  year=0;
  speed=0;
  model="";
  type="";
}
 Vehicle::Vehicle(int year, int speed, string type, string model){

 this->year=year;
 this->speed=speed;
 this->type=type;
 this->model=model;
 }
 void Vehicle::setSpeed(int speed){
  this->speed=speed;
}
void Vehicle::setYear(int year){
  this->year=year;
}
void Vehicle::setType(string type){
  this->type=type;
}
void Vehicle::setModel(string model){
  this->model=model;
}
int Vehicle::getSpeed()const{
  return speed;
}
int Vehicle::getYear(){
  return year;
}
string Vehicle::getType(){
  return type;
}
string Vehicle::getModel(){
  return model;
}
void Vehicle::addSpeed(int s){
  this->speed += s;
}
string Vehicle::toString(){
  return "I am a Vehicle";
}
string Vehicle::serveDrinks(){
  return "Drinks are only served in Planes";
}

