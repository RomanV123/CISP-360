
#include"Car.h"


using namespace std;

int Car::getWheelSize(){
  return wheelSize;
}

void Car::addSpeed(int s) {
  
  int newSpeed = getSpeed() + s;
  setSpeed(newSpeed);
}

string Car::serveDrinks() {
  return "Food and Drinks are not permitting in a Car";
}

string Car::toString() {
  return getType() + " " + getModel() + " " + to_string(getYear()) + " Speed " + to_string(getSpeed()) + " wheelSize " + to_string(getWheelSize());
}
 