#include "Plane.h"

Plane::Plane(){}
//default constructor

Plane::Plane(int year, int speed, std::string type, std::string model, int altitude) : Vehicle(year, speed, type, model)
{
	this->altitude = altitude;

}
//regular constructor

int Plane::getAltitude()
{
	return altitude;
}
//returns current height of hte plane

void Plane::setAltitude(int height)
{
	this->altitude = height;
}
//sets the altitude of the plane provided it is a positive number < 300000

std::string Plane::serveDrinks()
{
	return "Water and apple juice available";
} //function is unique to plane class
