//#pragma once
#ifndef Vehicle_h
#define Vehicle_h
#include <string>
#include <iostream>
class Vehicle
{
//attributes of the Vehicle class
private:
  int year;
  int speed;
  std::string type;
  std::string model;
  
// default and custom constructor of the Vehicle class
public:
Vehicle();
Vehicle(int year, int speed, std::string type, std::string model);
//getters and setters for each field
  void setSpeed(int speed); //sets speed
  void setYear(int year); //sets year
  void setModel(std::string model); //sets model
  void setType(std::string type); //sets type
  int getSpeed()const; //gets speed
  int getYear(); //gets year
  std::string getType(); //gets type
  std::string getModel(); //gets model
 //other methods of the Vehicle class
  void addSpeed(int s); 
  std::string toString(); //returns "I am a vehicle"
  std::string serveDrinks(); //returns "drinks only served on planes"

};
#endif