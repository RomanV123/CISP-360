#pragma once
#include "Vehicle.h"
class Plane: public Vehicle
{
  private:
      int altitude;
      //current height of the plane

  public: 
    Plane();
    //default constructor

    Plane(int year, int speed, std::string type, std::string model, int altitude);
   //regular constructor

    int getAltitude();
    //returns current height of hte plane

    void setAltitude(int height);
    //sets the altitude of the plane provided it is a positive number < 300000

    std::string serveDrinks();
    //returns "Water and apple juice available"
};