#include"Car.h"

Car::Car(){};
Car::Car(int year, int speed, std::string type, std::string model, int wheelSize) : Vehicle(year, speed, type, model)
{
	this->wheelSize = wheelSize;
}
std::string Car::serveDrinks()
{
	//keep empty
	return 0;
}


int Car::getWheelSize()
{
	return wheelSize;
}
//returns wheel size of car

std::string Car::toString()
{
	std::string value = getType() + " " + getModel() + " " + 
		std::to_string(getYear()) + " " + "Speed " + 
		std::to_string(getSpeed()) + "wheelSize" + " " +
		std::to_string(getWheelSize());
	return value;
}
//returns string representation of the car object

