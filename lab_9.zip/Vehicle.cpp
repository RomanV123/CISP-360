#include "Vehicle.h"

Vehicle::Vehicle(){}

Vehicle::Vehicle(int year, int speed, std::string type, std::string model)
{
	this->year = year;
	this->speed = speed;
	this->type = type;
	this->model = model;
}
//getters and setters for each field
void Vehicle::setSpeed(int speed)
{
	this->speed = speed; //sets speed
}
void Vehicle::setYear(int year)
{
	this->year = year; //sets year
}
void Vehicle::setModel(std::string model)
{
	this->model = model; //sts model
}
void Vehicle::setType(std::string type)
{
	this->type = type; //sets type
}
int Vehicle::getSpeed()const
{
	return speed; //gets speed
}
int Vehicle::getYear()
{
	return year; //gets year
}
std::string Vehicle::getType()
{
	return type; //gets type
}
std::string Vehicle::getModel()
{
	return model; //get model
}

void Vehicle::addSpeed(int s)
{
	//keep empty for now
}
std::string Vehicle::toString()
{
	return "I am a vehicle";
}//inherited by the plane class

std::string Vehicle::serveDrinks()
{
	return "drinks only served on planes";
} 
