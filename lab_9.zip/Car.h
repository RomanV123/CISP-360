#pragma once
#include "Vehicle.h"

class Car: public Vehicle
{
private:
  int wheelSize; //size of the car's wheels

 //constructors of the Car Class
public:
  Car();
  Car(int year, int speed, std::string type, std::string model, int wheelSize);
  std::string serveDrinks(); 
  //keep empty

  int getWheelSize(); 
  //returns wheel size of car

  std::string toString(); 
  //returns string representation of the car object
};
