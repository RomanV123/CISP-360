#include <iostream>
#include "Plane.h"
#include "Car.h"
#include <memory>
#include<vector>
#include<typeinfo>
int main() {
//create a shared pointer called car to a Car object and construct the car

  std::shared_ptr<Car> car = std::make_shared<Car>(1992,20,"Car","Honda",40);
  std::cout<<"-----------------------------------"<<std::endl;
  std::cout<<"Making a Car "<< std::endl;
  std::cout<<"Model: "<<car->getModel()<<std::endl;
  std::cout<<"Year: "<<car->getYear()<<std::endl;
  std::cout<<"Speed: "<<car->getSpeed()<<std::endl;
  std::cout<<"WheelSize: "<<car->getWheelSize()<<std::endl;

//create a shared pointer called plane to a Plane object and construct the plane


  std::shared_ptr<Plane> plane= std::make_shared<Plane>(2020,200,"Plane","Boeing",3000);
 
  std::cout<<"-----------------------------------"<<std::endl;
  std::cout<<"Making a Plane "<< std::endl;
  std::cout<<"Model: "<<plane->getModel()<<std::endl;
  std::cout<<"Year: "<<plane->getYear()<<std::endl;
  std::cout<<"Speed: "<<plane->getSpeed()<<std::endl;
  std::cout<<"Altitude: "<<plane->getAltitude()<<std::endl;
  std::cout<<"-----------------------------------"<<std::endl;

// call the getWheelSize() and toString() functions on the car  
  std::cout<<"I am a car and my wheelSize is "<<car->getWheelSize()<< std::endl;
  std::cout<<"Using the toString function: "<<car->toString();
  std::cout << std::endl << std::endl;

// call the getAltitude() and toString() functions on the plane  
  std::cout<<"I am a plane and my altitude is "<<plane->getAltitude()<< std::endl;
  std::cout<<"Using the toString function: "<<plane->toString()<< std::endl<< std::endl;
  std::cout<<"-----------------------------------"<< std::endl;

  std::cout<<"Creating a plane of Declared Type Plane and actual type Plane"<< std::endl;
  std::cout<<"Serve Drinks Function Overriden by Plane Class"<< std::endl;
  std::shared_ptr<Plane> plane2= std::make_shared<Plane>(2000,100,"Plane","Lockheed",5000);
  
  std::cout<<"Plane says: "<<plane2->serveDrinks()<< std::endl;
  

  std::cout<<"-----------------------------------"<< std::endl;
  std::cout<<"Creating a plane of Declared Type Vehicle and actual type Plane"<< std::endl;
   std::shared_ptr<Vehicle> plane3= std::make_shared<Plane>(1000,100,"Plane","Hughes",2000);
   std::cout<<"Serve Drinks Function Not Overriden by Plane Class, Vehicle Class prevails "<< std::endl;
   std::cout<<"Vehicle Says: "<<plane3->serveDrinks()<< std::endl;
  }
  
