#include "Vehicle.h"

Vehicle::Vehicle(){}

Vehicle::Vehicle(int year, int speed, std::string type, std::string model)
{
	this->year = year;
	this->speed = speed;
	this->type = type;
	this->model = model;
}
//getters and setters for each field
void Vehicle::setSpeed(int speed)
{
	this->speed = speed; 
}
void Vehicle::setYear(int year)
{
	this->year = year; 
}
void Vehicle::setModel(std::string model)
{
	this->model = model; 
}
void Vehicle::setType(std::string type)
{
	this->type = type; 
}
int Vehicle::getSpeed()const
{
	return speed; 
}
int Vehicle::getYear()
{
	return year; 
}
std::string Vehicle::getType()
{
	return type; 
}
std::string Vehicle::getModel()
{
	return model; 
}

void Vehicle::addSpeed(int s)
{
	
}
std::string Vehicle::toString()
{
	return "I am a vehicle";
}

std::string Vehicle::serveDrinks()
{
	return "drinks only served on planes";
} 
