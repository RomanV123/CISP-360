#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <cstdlib>
#include "BankHeader.h"

string Bank::quickgetAccountName() {

    string firstName, lastName;
    cout << "What is the Account First Name: ";
    cin >> firstName;
    cout << "What is the Account Last Name: ";
    cin >> lastName;

    return firstName + ", " + lastName;
}

int Bank::quickgetAccountNumber() {
    int number;
    cout << "What is the Account Number: ";
    cin >> number;
    return number;
}

double Bank::quickgetAmount() {
    double number;
    cout << "What is the Dollar Amount: ";
    cin >> number;

    return number;
}

int Bank::binarySearch(vector<shared_ptr<BankAccount>>& accountVector, int accountNumber, string accountName) {

    int first, middle, last;
    first = 0; last = accountVector.size();
    middle = (first + last) / 2;


    while (first <= last) {
        if (accountVector[middle]->getAccountName() == accountName && accountVector[middle]->getAccountNumber() == accountNumber)
            return middle;
        else {
            if (accountVector[middle]->getAccountNumber() < accountNumber)
                first = middle + 1;
            else last = middle - 1;
        }
        middle = (first + last) / 2;
    }
    return -1;

}

Bank::Bank(string fileName) {


    ifstream inputFile(fileName);
    fillVector(inputFile, accountVector);

    sort(accountVector);
    printVector(accountVector);

}

void Bank::withdraw() {

    string tempName = quickgetAccountName();
    int tempNum = quickgetAccountNumber();

    int index = binarySearch(accountVector, tempNum, tempName);
    if (index >= 0) {
        double temp = quickgetAmount();
        accountVector[index]->withdraw(temp);


        cout << "\n";
        cout << "----------------------------------\n";
        cout << accountVector[index]->toString();
        cout << "----------------------------------\n";


    }

    else {
        cout << "Account Not Found \n";
    }



}

void Bank::viewBalance() {

    string tempName = quickgetAccountName();
    int tempNum = quickgetAccountNumber();
    
    int index = binarySearch(accountVector, tempNum, tempName);
    if (index >= 0) {

        cout << "\n";
        cout << "----------------------------------\n";
        cout << accountVector[index]->toString();
        cout << "----------------------------------\n";
        

    }
    else {
        cout << "Account not found \n";
    }
}

void Bank::deposit(){

    string tempName = quickgetAccountName();
    int tempNum = quickgetAccountNumber();

    int index = binarySearch(accountVector, tempNum, tempName);
    if (index >= 0) {


        double temp = quickgetAmount();
        accountVector[index]->deposit(temp);

        cout << "\n";
        cout << "----------------------------------\n";
        cout << accountVector[index]->toString();
        cout << "----------------------------------\n";

        
    }
    else {
        cout << "Account not found \n";
    }

}

void Bank::fillVector(ifstream &input, vector<shared_ptr<BankAccount>> &accountVector) {

    string fname, lname;
    string name;
    string data;
    int num, id;
    double balance; 
    istringstream instream;
    

    try {
        if (input) {
            while (!input.eof()) {
                getline(input, data);
                istringstream instream(data);
                instream >> fname;
                instream >> lname;
                instream >> id;
                instream >> num;
                instream >> balance;

                name = fname + ", " + lname;
                shared_ptr<BankAccount> temp = make_shared <BankAccount>(name, id, num, balance);
                accountVector.push_back(temp);

            }
        }

        else throw string("File not Found");
    }
    catch (string message) {
        cout << message << endl;
        exit(0);
    }

}

void Bank::printVector(vector<shared_ptr<BankAccount>> &accountVector){

    for (int i = 0; i < accountVector.size(); i++) {
    
        cout << accountVector[i]->toString() << "\n";

    }


}

void Bank::sort(vector<shared_ptr<BankAccount>> &accountVector) {

    if (accountVector.size() > 1) {
        shared_ptr<BankAccount> temp;
        for (int i = 0; i < accountVector.size() - 1; i++) {
            for (int j = 0; j < accountVector.size() - i - 1; j++) {
                if ((accountVector[j]->getAccountNumber()) > (accountVector[j+1]->getAccountNumber())) {
                    temp = accountVector[j];
                    accountVector[j] = accountVector[j + 1];
                    accountVector[j + 1] = temp;
                }
            }
        }
    }

}