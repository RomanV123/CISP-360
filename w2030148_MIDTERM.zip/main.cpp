/***********************************
PROJECT    : Mid-Term Project
Name       : Ethan Tan
Description: This project focuses on
the first half of the CISP 400 Course.
This project will expand on the idea
of object-oriented programming, working
with vectors, objects, shared pointers,
etc...
***********************************/
//Note: BankHeader.h will use BankAccountHeader.h 

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <cstdlib>
#include "BankHeader.h" 


char printMenu(Bank myBank) {
    char menuOp;
    string toFind;
   

    cout << endl << "Menu" << endl;
    cout << "v - View Account Balance" << endl;
    cout << "w - Withdraw from Account" << endl;
    cout << "d - Deposit into Account" << endl;
    cout << "a - Add an Account " << endl;
    cout << "r - Remove an Account" << endl;

    cout << "q - Quit" << endl << endl;

    menuOp = ' ';

    while (menuOp != 'd' && menuOp != 'a' && menuOp != 'v' && menuOp != 'r' && menuOp != 'w' && menuOp != 'q') {
        cout << "choose an option: ";
        string s;
        getline(cin, s, '\n');
        cin.clear();
        menuOp = s[0];
        menuOp = tolower(menuOp);


    }

    if (menuOp == 'r') {
        std::cout << "Remove Account: Coming Soon" << endl;

        menuOp = ' ';
        cin.clear();
    }
    else if (menuOp == 'd') {
        myBank.deposit();
        menuOp = ' ';
        cin.ignore(9999, '\n');
    }
    else if (menuOp == 'v') {
        myBank.viewBalance(); 
        menuOp = ' ';
        cin.ignore(9999, '\n');
    }

    else if (menuOp == 'w') { 
      
        myBank.withdraw();      
        menuOp = ' ';
        cin.ignore(9999, '\n');


    }

    else if (menuOp == ' ') {
        menuOp = ' ';
        cin.ignore(9999, '\n');
    }

    else if (menuOp == 'a') {
        std::cout << "Add Account: Coming Soon" << endl;
        menuOp = ' ';
        cin.clear();
    }
    else if (menuOp == 'q') {
        std::cout << "Good Bye!" << endl;
    }
    return menuOp;
}

int main() {

    Bank myBank("c://temp//BankData.txt");
    char option = printMenu(myBank);
    while (option != 'q') {
        option = printMenu(myBank);
    }

}

