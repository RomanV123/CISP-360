//Note: Bankheader.h will use this header file in its work
using std::string;

class BankAccount {

private: 
	const static double MIN_BALANCE;
	const static double REWARD_RATE;
	const static double MIN_REWARD_AMOUNT;
	

	int accountNumber;
	int id;
	string accountName;
	double accountBalance;

	//private functions

	void addReward(double amount);
	int getId();



public:
	static int count;

	//two constructors
	BankAccount();
	BankAccount(string accountname, int id, int accountNumber, double accountBalance);

	//getters

	string getAccountName();
	int getAccountNumber();
	double getAccountBalance();

	//setters

	void setAccountBalance(double accountBalance);

	string toString();


	bool withdraw(double amount);
	void deposit(double amount);
	bool equals(BankAccount other);


};
