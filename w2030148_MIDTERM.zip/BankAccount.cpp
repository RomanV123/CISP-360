#include <string>
#include <iostream>
#include "BankAccountHeader.h"
#include <iomanip>

using std::string;



//Default Constructor

BankAccount::BankAccount() {
	this->id = 0;
	this->accountBalance = 0;
	this->accountNumber = 0;
	this->accountName = "";
	count++;

}

//Constructor
BankAccount::BankAccount(string accountName, int id, int accountNumber, double accountBalance ) {
	this->id = id;
	this->accountNumber = accountNumber;
	this->accountName = accountName;
	this->accountBalance = accountBalance;
	count++;

}

//getter functions
string BankAccount::getAccountName() {
	return accountName;
	
}

int BankAccount::getAccountNumber() {
	return accountNumber;

}

double BankAccount::getAccountBalance() {
	return accountBalance;

}


int BankAccount::getId() {
	return id;

}

//setter functions
void BankAccount::setAccountBalance(double accountBalanace) {
	this->accountBalance = accountBalanace;

}

//toString function to print Accounts
string BankAccount::toString() {
	std::cout << std::fixed << std::setprecision(2);        //to string module that will display everything

	return "Account Name: " + (accountName)+"\n" + 
		   "Account Number: " + std::to_string(accountNumber).substr(0, 4) + "\n"+ 
		   "Account Balance: $" + std::to_string(accountBalance).substr(0, std::to_string(accountBalance).find(".") + 3) + "\n";


}

bool BankAccount::withdraw(double amount) {

	if (accountBalance - amount > MIN_BALANCE) {
		accountBalance -= amount;
		return true;

	}
	else {
		std::cout << std::endl;
		std::cout << "Insufficient Funds";

		return false;

	}
}

void BankAccount::deposit(double amount) {

	accountBalance += amount;
	if (amount > MIN_REWARD_AMOUNT) {
		addReward(amount);
	}
}

void BankAccount::addReward(double amount) {

	accountBalance += accountBalance + (REWARD_RATE * amount);

}

bool BankAccount::equals(BankAccount other) {

	if (accountName == other.accountName && id == other.id) {
		return true;

	}
	else {
		return false;
	}
	
}

const double BankAccount::MIN_BALANCE = 9.99;
const double BankAccount::MIN_REWARD_AMOUNT = 1000.0;
const double BankAccount::REWARD_RATE = 0.04;

int BankAccount::count = 0;

