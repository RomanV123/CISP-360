#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <cstdlib>//for exit
#include "BankAccountHeader.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::istringstream;
using std::ifstream; 
using std::vector;
using std::shared_ptr;
using std::make_shared;


class Bank {
private:
	shared_ptr<BankAccount> bankPtr;
	vector<shared_ptr<BankAccount>> accountVector;

public:

	string quickgetAccountName();
	int quickgetAccountNumber();
	double quickgetAmount();
	int binarySearch(vector<shared_ptr<BankAccount>>& accountVector, int accountNumber, string accountName);
	Bank(string filename);
	void withdraw();
	void viewBalance();
	void deposit();
	void fillVector(ifstream &input, vector<shared_ptr<BankAccount>> &accountVector);
	void printVector(vector<shared_ptr<BankAccount>> &accountVector);
	void sort(vector<shared_ptr<BankAccount>>& accountVector);
	
};