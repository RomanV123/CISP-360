// Circle.h (Header file)
#ifndef CIRCLE_H
#define CIRCLE_H

#include <string>
#include <cmath>

class Circle {
private:
    int x;
    int y;
    int radius;
    static int count;

public:
    // Constructors
    Circle();
    Circle(int x, int y, int radius);

    // Accessors
    int getX() const;
    int getY() const;
    int getRadius() const;
    static int getCount();

    // Mutators
    void setX(int newX);
    void setY(int newY);
    void setRadius(int newRadius);

    // Other member functions
    double getArea() const;
    double getCircumference() const;
    std::string toString() const;
    double getDistance(const Circle& other) const;
    void moveTo(int newX, int newY);
    bool intersects(const Circle& other) const;
    void resize(double scale);
    Circle resize(int scale);

    
    ~Circle();
};

#endif

