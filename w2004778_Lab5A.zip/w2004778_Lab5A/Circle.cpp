
#include "Circle.h"
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>

// Initialize static member variable
int Circle::count = 0;

// Constructors
Circle::Circle() : x(0), y(0), radius(1) {
    count++;
}

Circle::Circle(int x, int y, int radius) : x(x), y(y), radius(radius) {
    count++;
}

// Accessors
int Circle::getX() const {
    return x;
}

int Circle::getY() const {
    return y;
}

int Circle::getRadius() const {
    return radius;
}

int Circle::getCount() {
    return count;
}

// Mutators
void Circle::setX(int newX) {
    x = newX;
}

void Circle::setY(int newY) {
    y = newY;
}

void Circle::setRadius(int newRadius) {
    radius = newRadius;
}

// Other member functions (implement these according to your requirements)
double Circle::getArea() const {
    // Implement the formula for area
    return M_PI * radius * radius;
}

double Circle::getCircumference() const {
    // Implement the formula for circumference
    return 2 * M_PI * radius;
}

std::string Circle::toString() const {
    // Implement toString method
    return "(" + std::to_string(x) + "," + std::to_string(y) + ") : " + std::to_string(radius);
}

double Circle::getDistance(const Circle& other) const {
    // Implement the formula to calculate distance between centers of two circles
    return sqrt(pow(x - other.x, 2) + pow(y - other.y, 2));
}

void Circle::moveTo(int newX, int newY) {
    // Implement moveTo method
    x = newX;
    y = newY;
}

bool Circle::intersects(const Circle& other) const {
    // Implement intersects method
    return getDistance(other) < (radius + other.radius);
}

void Circle::resize(double scale) {
    // Implement resize method
    radius *= scale;
}

Circle Circle::resize(int scale) {
    // Implement resize method with int scale
    Circle resizedCircle(*this);
    resizedCircle.radius *= scale;
    return resizedCircle;
}

// Destructor (as requested)
Circle::~Circle() {
    std::cout << "Inside Destructor" << std::endl;
}
