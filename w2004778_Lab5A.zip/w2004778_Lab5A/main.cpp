//Roman Vasilyev 9/29/2023

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Circle.h" // Include the Circle class header file

using namespace std;

// Function to read data from a file and populate the vector of circles
void inputData(vector<Circle>& circles, string filename) {
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "File Open Error" << endl;
        exit(1); // Exit the program if the file cannot be opened
    }

    string line;
    while (getline(file, line)) {
        istringstream instream(line);
        int x, y, radius;
        instream >> x >> y >> radius;
        Circle circle(x, y, radius);
        circles.push_back(circle);
    }

    file.close();
}

int main() {
    vector<Circle> circles;

    // Call the inputData function to populate the vector from "dataLab4.txt"
    inputData(circles, "C:/Users/roman/Downloads/dataLab5B.txt");

    // Display all circles in the vector using toString
    for (const auto& circle : circles) {
        cout << circle.toString() << endl;
    }

    // Display the count of circles in the vector using getCount
    cout << "Count of circles (using getCount): " << Circle::getCount() << endl;

    // Display the count of circles in the vector using vector size method
    cout << "Count of circles (using vector size): " << circles.size() << endl;

    // Erase circles with a radius greater than 8
    auto it = circles.begin();
    while (it != circles.end()) {
        if (it->getRadius() > 8) {
            it = circles.erase(it);
        }
        else {
            ++it;
        }
    }

    // Display the number of circles remaining using vector size method
    cout << "Number of circles remaining: " << circles.size() << endl;

    // Display all remaining circles using toString
    for (const auto& circle : circles) {
        cout << circle.toString() << endl;
    }

    // Create new Circle objects and insert them into the vector
    Circle circle1(3, 4, 7);
    Circle circle2(-2, -4, 4);

    // Insert circle1 at position 2 and circle2 at position 3
    circles.insert(circles.begin() + 2, circle1);
    circles.insert(circles.begin() + 3, circle2);
    std::cout << "The rest of the circles are : " << std::endl;

    // Display the updated vector of circles
    for (const auto& circle : circles) {
        cout << circle.toString() << endl;
    }

    return 0;
}
