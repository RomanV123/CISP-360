#include "Dragon.h"
#include "MagicalCreatures.h"

Dragon::Dragon(){}
//default constructor

Dragon::Dragon(std::string name, std::string color, std::string type, int age, int size, bool hasSpikes) :MagicalCreatures(name, color, type, age)
{
	this->size = size;
	this->hasSpikes = hasSpikes;
}
//regular constructor

int Dragon::getSize()
{
	return size;
}
//gets size

bool Dragon::getHasSpike()
{
	return hasSpikes;
}
//set to true

void Dragon::changeSize(int newSize)
{
	size = newSize;
}
//grows big or small

void Dragon::setHasSpike(bool hasSpike)
{
	this->hasSpikes = hasSpike;
}
//set to true

std::string Dragon::toString()
{
	std::string value = "I am a dragon. I breathe fire!";
	return value;
}
//overrides toString function from parent class