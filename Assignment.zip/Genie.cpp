//Name
//Genie.cpp
#include "Genie.h"
#include "MagicalCreatures.h"

Genie::Genie(){}
//default constructor

Genie::Genie(std::string name, std::string color, std::string type, int age, int size, bool hasWand) :MagicalCreatures(name, color, type, age)
{
	this->size = size;
	this->hasWand = hasWand;
}
//regular constructor

int Genie::getSize()
{
	return size;
}
//gets size

bool Genie::getHasWand()
{
	return hasWand;
}
//set to true

void Genie::changeSize(int newSize)
{
	size = newSize;
}
//grows big or small

void Genie::setHasWand(bool hasWand)
{
	this->hasWand = hasWand;
}
//set to true

std::string Genie::liveIn()
{
	std::string value = "I live in a bottle";

	return value;
	//overrides liveIn function from parent class
}
