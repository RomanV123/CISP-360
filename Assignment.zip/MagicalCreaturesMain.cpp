#include<memory>
#include "Dragon.h"
#include "Elf.h"
#include "Genie.h"
#include "Goblin.h"
#include <iterator>

//function takes a shared pointer to a dragon and calls its toString function
void displayDragons(std::shared_ptr<Dragon> d);

int main()
{
	//create a vector of shared pointer to Dragons
	std::vector<std::shared_ptr<Dragon>> dragonVector;

	//create the individual creatures of type pointer of MagicalCreatures
	std::shared_ptr<Dragon> dragon = std::make_shared<Dragon>("Jack", "Black", "Dragon", 200, 500, true);
	std::shared_ptr<Dragon> dragoness = std::make_shared<Dragon>("Jill", "White", "Dragon", 100, 500, true);
	std::shared_ptr<Elf> elf = std::make_shared<Elf>("Doug", "green", "Elf", 80);
	std::shared_ptr<Genie> genie = std::make_shared<Genie>("Cosmo", "Blue", "Genie", 1000, 40, true);
	std::shared_ptr<Goblin>  goblin = std::make_shared<Goblin>("Harry", "Red", "Goblin", 150); 

	//pushes each pointer to Dragon into the dragonVector
	dragonVector.push_back(dragon);
	dragonVector.push_back(dragoness);

	//print the traits of each creature 
	std::cout << "Printing traits of each magical creature: " << std::endl;
	std::cout << "-------------------------------------------------" << std::endl;
	std::cout << "Name: " << dragon->getName() << std::endl;
	std::cout << "Type: " << dragon->getType() << std::endl;
	std::cout << "Color: " << dragon->getColor() << std::endl;
	std::cout << "Age: " << dragon->getAge() << std::endl;
	std::cout << "Talk: " << dragon->talk() << std::endl;
	std::cout << "Live: " << dragon->liveIn() << std::endl;
	std::cout << "To String: " << dragon->toString() << std::endl;
	std::cout << "------------------------------" << std::endl;

	//using individual getters for each creature
	std::cout << "Name: " << dragoness->getName() << std::endl;
	std::cout << "Type: " << dragoness->getType() << std::endl;
	std::cout << "Color: " << dragoness->getColor() << std::endl;
	std::cout << "Age: " << dragoness->getAge() << std::endl;
	std::cout << "Talk: " << dragoness->talk() << std::endl;
	std::cout << "Live: " << dragoness->liveIn() << std::endl;
	std::cout << "To String: " << dragoness->toString() << std::endl;
	std::cout << "------------------------------" << std::endl;

	std::cout << "Name: " << elf->getName() << std::endl;
	std::cout << "Type: " << elf->getType() << std::endl;
	std::cout << "Color: " << elf->getColor() << std::endl;
	std::cout << "Age: " << elf->getAge() << std::endl;
	std::cout << "Talk: " << elf->talk() << std::endl;
	std::cout << "Live: " << elf->liveIn() << std::endl;
	std::cout << "To String: " << elf->toString() << std::endl;
	std::cout << "------------------------------" << std::endl;

	std::cout << "Name: " << genie->getName() << std::endl;
	std::cout << "Type: " << genie->getType() << std::endl;
	std::cout << "Color: " << genie->getColor() << std::endl;
	std::cout << "Age: " << genie->getAge() << std::endl;
	std::cout << "Talk: " << genie->talk() << std::endl;
	std::cout << "Live: " << genie->liveIn() << std::endl;
	std::cout << "To String: " << genie->toString() << std::endl;
	std::cout << "------------------------------" << std::endl;

	std::cout << "Name: " << goblin->getName() << std::endl;
	std::cout << "Type: " << goblin->getType() << std::endl;
	std::cout << "Color: " << goblin->getColor() << std::endl;
	std::cout << "Age: " << goblin->getAge() << std::endl;
	std::cout << "Talk: " << goblin->talk() << std::endl;
	std::cout << "Live: " << goblin->liveIn() << std::endl;
	std::cout << "To String: " << goblin->toString() << std::endl;
	std::cout << "------------------------------" << std::endl;

	//create an iterator in a for loop to call displayDragons
	for (auto iter = dragonVector.begin(); iter != dragonVector.end(); iter++)
	{
		displayDragons(*iter);
	}
}

void displayDragons(std::shared_ptr<Dragon> d)
{
	std::cout << "In displayDragons:" << std::endl;
	std::cout << "I am " + d->getName() + ". ";
	std::cout <<  d->toString() << std::endl;
    //calls toString for each dragon
}