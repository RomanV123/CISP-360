//Name
//Genie.h
#ifndef Genie_h
#define Genie_h
#include "MagicalCreatures.h"
class Genie : public MagicalCreatures
{
private:
	bool hasWand;
	int size;

public:
	Genie();
	//default constructor

	Genie(std::string name, std::string color, std::string type, int age, int size, bool hasWand);
	//regular constructor

	int getSize();
	//gets size

	bool getHasWand();
	//set to true

	void changeSize(int newSize);
	//grows big or small

	void setHasWand(bool hasWand);
	//true if the genie has a wand

	std::string liveIn();
	//overrides liveIn function from parent class
	};

#endif
