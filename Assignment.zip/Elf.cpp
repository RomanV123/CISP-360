#include "Elf.h"
#include "MagicalCreatures.h"

Elf::Elf(){}
//default constructor

Elf::Elf(std::string name, std::string color, std::string type, int age) : MagicalCreatures(name, color, type, age){}
//regular constructor

std::string Elf::toString()
{
	std::string value = "I am an elf..I can spell";
	return value;
	//overrides toString function from parent class
}
