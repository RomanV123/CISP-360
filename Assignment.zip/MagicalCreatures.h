#ifndef MagicalCreatures_h
#define MagicalCreatures_h

#include <string> 
#include <iostream>
#include <vector>
#include <algorithm>

//MagicalCreatures Class
class MagicalCreatures
{
private:
	std::string name, color, type;
	int age;

public:
	//default constructor
	MagicalCreatures();
	//custom constructor
	MagicalCreatures(std::string name, std::string color, std::string type, int age);

	//getters and setters for each attribute
	std::string getName();
	std::string getColor();
	std::string getType();
	int getAge();

	void setName(std::string name);
	void setColor(std::string color);
	void setType(std::string type);
	void setAge(int age);

	std::string  talk();
	// talk method: what does a magical creature say

	std::string liveIn();
	// live in function: where does a magical creature live 

	std::string toString();
	// returns string representation of the magical creature
};

#endif