
#include "MagicalCreatures.h"
//implement all the methods in the header
//given to you as a gift:)

MagicalCreatures::MagicalCreatures()
{
	name = " ";
	color = " ";
	type = " ";
	age = 0;
	//default constructor
}
MagicalCreatures::MagicalCreatures(std::string name, std::string color, std::string type, int age)
{
	this->name = name;
	this->color = color;
	this->type = type;
	this->age = age;
	//regular constructor
}
std::string MagicalCreatures::getName()
{
	return name;
	//gets the name
}

std::string MagicalCreatures::getType()
{
	return type;
	//gets the type
}

int MagicalCreatures::getAge()
{
	return age;
	//gets the age
}

std::string MagicalCreatures::getColor()
{
	return color;
	//gets the color
}
void MagicalCreatures::setName(std::string name)
{
	this->name = name;
	//sets the name
}
void MagicalCreatures::setAge(int age)
{
	this->age = age;
	//sets the age
}

void MagicalCreatures::setColor(std::string color)
{
	this->color = color;
	//sets the color
}

void MagicalCreatures::setType(std::string type)
{
	this->type = type;
	//sets the type
}

std::string MagicalCreatures::talk()
{
	std::string value = "Magical Creature is talking.";

	return value;
	//parent function for creatures to talk
}

std::string MagicalCreatures::liveIn()
{
	std::string empty = "Magical Creature lives anywhere.";

	return empty;
	//parent function for where creatures live
}

std::string MagicalCreatures::toString()
{
	std::string value = "I am a Magical creature ";
	value = value.append("\nName    : ");
	value = value.append(name);
	value = value.append("\nType    : ");
	value = value.append(type);
	value = value.append("\nColor   : ");
	value = value.append(color);
	value = value.append("\nAge     : ");
	value = value.append(std::to_string(age));

	//returns the object description as a string
	return value;
}
