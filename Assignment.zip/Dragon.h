#ifndef Dragon_h
#define Dragon_h

#include "MagicalCreatures.h"

class Dragon : public MagicalCreatures
{
private:
	bool hasSpikes;
	int size;

public:
	Dragon();
	//default constructor

	Dragon(std::string name, std::string color, std::string type, int age, int size, bool hasSpikes);
	//regular constructor

	int getSize();
	//gets size

	bool getHasSpike();
	//set to true

	void changeSize(int newSize);
	//grows big or small

	void setHasSpike(bool hasSpike);
	//true if the dragon has a spike

	std::string toString();
	//overrides toString function from parent class
};

#endif