#include <iostream>
using std::string;
int inputNumber();
bool checkMultiple7(int number);
void displayResults(string message);
void runNumberCheck();