/**********************************
Name: Roman Vasilyev
Date: 8/31/23
***********************************/
#include "CheckMultiple7Header.h"

int main() {
    runNumberCheck();
    return 0;
}