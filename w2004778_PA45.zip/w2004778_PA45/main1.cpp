//Roman Vasilyev 9/27/2023 Assignment 4 and 5 
 

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "BankAccount1.h" 

// array
//fills the vector
void fillArray(std::ifstream& input, std::vector<BankAccount>& accounts);
//finds account with largest balance and returns index
int largest(std::vector<BankAccount>& accounts);
//finds account with smallest balance and returns index
int smallest(std::vector<BankAccount>& accounts);
//displays all bank accounts
void printVector(std::vector<BankAccount>& accounts);
//check for duplicates in the vector

void checkDuplicates(std::vector<BankAccount>& accounts);
//fills a temp object with data to insert in the vector
void insertAccount(std::string name, int Id, int number, double balance, BankAccount& temp);


int main() {
    //create vector of objects with data type BankAccount
    std::vector<BankAccount>accounts;
    // open the file
    std::ifstream input("C:/Users/roman/OneDrive/Desktop/CompSci folder/Assignment-3-Template/BankData.txt"); //specific pathway I use to get to the file BankData.txt only does not work for some reason. 
    //if open fails
    if (!input)
        std::cout << "File Open Error";
    else {
        //fills the vector
        fillArray(input, accounts);
        //displays the vector
        printVector(accounts);
        
        std::cout << "Largest Balance: " << std::endl;
        std::cout << accounts[largest(accounts)].toString() << std::endl;

        
        std::cout << "Smallest Balance :" << std::endl;
        std::cout << accounts[smallest(accounts)].toString() << std::endl;

        std::cout << "Using the static count, there are " << BankAccount::count << " accounts" << std::endl;
        std::cout << "Using vector size, there are " << accounts.size() << " accounts" << std::endl;
        //outputs the number of accounts using two different methods

        checkDuplicates(accounts);
        //checks for duplicates and adjusts vector

        std::cout << "Using the static count, there are " << BankAccount::count << " accounts" << std::endl;
        std::cout << "Using vector size, there are " << accounts.size() << " accounts" << std::endl;
        //outputs the number of accounts using two different methods


        BankAccount temp;
        //temporarily hold the info

        insertAccount("Amy Machado", 387623, 1244, 1023.67, temp);
        

        accounts.insert(accounts.begin() + 2, temp);
        //adds the temporary object to the vector 

        insertAccount("Tak Phen", 981243, 1262, 6423.02, temp);
        accounts.insert(accounts.begin() + 4, temp);

        insertAccount("Celia Beatle", 465281, 1276, 3.56, temp);
        accounts.insert(accounts.begin() + 6, temp);

        std::cout << "Inserted Three New Accounts: Reprinting List" << std::endl;
        printVector(accounts);
        //displays three new vectors

        std::cout << "Using the static count, there are " << BankAccount::count << " accounts" << std::endl;
        std::cout << "Using vector size, there are " << accounts.size() << " accounts" << std::endl;
        //outputs the number of accounts using two different methods
    }
}

void insertAccount(std::string name, int Id, int number, double balance, BankAccount& temp)
{
    temp.setAccountName(name);
    temp.setId(Id);
    temp.setNumber(number);
    temp.setAccountBalance(balance);
    //sets temporary object with new info

    BankAccount::count += 1;
    //increment the bank account counter
}

void checkDuplicates(std::vector<BankAccount>& accounts) {
    bool duplicate = 1;

    for (int i = 0; i < accounts.size(); i++) {
        for (int j = i + 1; j < accounts.size(); j++) {
            if (accounts[i].equals(accounts[j]))
            {
                accounts.erase(accounts.begin() + j);
                duplicate = 0;
            }
        }
    }
    

    if (duplicate) {
        std::cout << "Duplicate Accounts Found : Reprinting List " << std::endl << std::endl;
        printVector(accounts);
    }
    //reprint the accounts after finding duplicates
}


void fillArray(std::ifstream& input, std::vector<BankAccount>& accounts)
{
    std::string accountName; std::string lastName; std::string firstName;
    int id, accountNumber;
    double accountBalance;
    std::string info;
    //variables to store data 

    while (!input.eof())
    {
        getline(input, info); //reads the file
        std::istringstream istream(info); 
        

        istream >> firstName >> lastName >> id >> accountNumber >> accountBalance;
        accountName = firstName + " " + lastName;
        //reads data into the stated variables. 

        BankAccount temp(accountName, id, accountNumber, accountBalance);
        accounts.push_back(temp);
        BankAccount::count += 1;
        
    }
}

int largest(std::vector<BankAccount>& accounts)
{
    double largest = 0; int index = 0;
    //search through the array using a for loop to find a bank account with the largest account balance. 
    for (int i = 1; i < accounts.size(); i++) {
        if (accounts[i].getAccountBalance() > largest) {
            largest = accounts[i].getAccountBalance();
            index = i;
        }
    }
    return index;
}
//searcj the array to find a bank account with the smalles account balance
int smallest(std::vector<BankAccount>& accounts) {
    double smallest = 0; int index = 0;
    for (int i = 1; i < accounts.size(); i++) {
        if (accounts[i].getAccountBalance() < smallest) {
            smallest = accounts[i].getAccountBalance();
            index = i;
        }
    }
    return index;
}

void printVector(std::vector<BankAccount>& accounts) {
    std::cout << "FAVORITE BANK - CUSTOMER DETAILS " << std::endl;
    std::cout << "--------------------------------" << std::endl;
    for (int i = 0;i < accounts.size();i++)
        std::cout << accounts[i].toString() << std::endl;

    //displays all the bank accounts in the vector
}
//main.cpp