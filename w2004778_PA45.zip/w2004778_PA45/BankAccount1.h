
// Roman Vasilyev 9/16/23 Assignment 3 

class BankAccount {
private:
    const static  double  MIN_BALANCE;
    const static double REWARD_RATE;
    const static double MIN_REWARD_AMOUNT;
    //constants

private:
    int accountNumber, id;
    std::string accountName;
    double accountBalance;
    void addReward(double amount);
    int getId();

public:
    static int count;

    BankAccount();
    //default constructor
    BankAccount(std::string accountName, int id, int accountNumber, double accountBalance);
    //constructor

public:
    bool duplicate;
    std::string getAccountName();
    int getAccountNumber();
    double getAccountBalance();
    int getCount();
    void setAccountName(const std::string& newName);
    void setId(int newId);
    void setNumber(int newNumber);
    void setAccountBalance(double accountBalance);
    std::string toString();
    bool withdraw(double amount);
    void deposit(double amount);
    bool equals(BankAccount other);

};
// BankAccount.h