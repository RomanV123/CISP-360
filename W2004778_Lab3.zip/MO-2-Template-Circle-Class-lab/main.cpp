#include <string>
#include <iostream>
#include <iomanip>
#include "CircleHeader.h"




int main() {

	std::cout << std::fixed << std::setprecision(0);			//setprecison and fixed so the values printed like area and circumference 
	
	Circle circleOne;
	Circle circleTwo(0, 0, 4);

	std::cout << "Created circleOne" << circleOne.toString() << std::endl;
	std::cout << "Created circleTwo" << circleTwo.toString() << std::endl;											//Prints out to the screen what the x, y, and radius values are to the user
	std::cout << "The distance between the two circles is: " << circleOne.getDistance(circleTwo) << " \n";		//Prints out the distance between circleOne and circleTwo


	if (circleOne.intersects(circleTwo) == true) {
		std::cout << "Circles One and Two do intersect " << std::endl;

	}
	//Conditional Statement to see if the two circles will intersect
	else {
		std::cout << "Circles One and Two do not intersect" << std::endl;
	}


	Circle circleThree(circleTwo.resize(10));									//resizes circleThree using circleTwo
	std::cout << "Created circleThree" << circleThree.toString() << std::endl;

	circleThree.move(4, 5);													//Moves circleThree
	std::cout << "Moved circle Three" << circleThree.toString() << std::endl;

	if (circleTwo.intersects(circleThree) == true) {
		std::cout << "Circles Two and Three do intersect" << std::endl;

	}
	
	else {
		std::cout << "Circles Two and Three do not intersect" << std::endl;
	}



	Circle circleFour(4, 5, 1);													//Creates circleFour and displays it
	std::cout << "Created circle Four" << circleFour.toString() << std::endl;
	if (circleFour.intersects(circleOne) == true) {
		std::cout << "Circles one and Four do intersect" << std::endl;

	}
	//Conditional Statement to see if the two circles will intersect
	else {
		std::cout << "Circles one and Four do not intersect" << std::endl;
	}




	circleThree.resize(9.5);
	std::cout << "Resized circle three" << circleThree.toString() << std::endl;			//resizes circleThree and displays aftermath 

	return 0;
}