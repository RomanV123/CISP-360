
class OutOfRange{
  private: 
 
  public: OutOfRange(int exNum){
    if (exNum == 99) {
      throw DivByZero(exNum);
    }
    else if (exNum == 100) {
      throw NegativeDenom(exNum);
    }
      // check exception number and throw the appropriate exceptions given below      
}

  public:
    class DivByZero{
      public: int exNum;
      DivByZero(int i){
        exNum=i;
      }
    };
    class NegativeDenom{
      public: int exNum;
      NegativeDenom(int i){
        exNum=i;
      }
    };
   
  
};
  
