//Name: Alex Gomez
// ID: w2082088

 
 #include <cstdlib>

 #include <iostream>

 using std::cout;
 using std::endl;

 #include "RationalNumber.h"
 #include "OutOfRange.cpp"
 RationalNumber::RationalNumber( int n, int d ){
 
  //constructor..here is where the try catch comes in
   // assign numerator and denominator and do the reduction
    try{
     if (d==0) throw OutOfRange(99);
     else if (d<0) throw OutOfRange(100);
 }
    catch (OutOfRange::DivByZero ex){
   cout <<"Division by Zero Error "<<ex.exNum<<endl;
   //exit(0);
   
 }
 catch (OutOfRange::NegativeDenom ex){
   
   cout <<"Negative Denominator Error "<<ex.exNum<<endl;
   exit(0);

 }
 {
      numerator = n;
      denominator = d;
      reduction();
 }
 }
  
string RationalNumber::toString() {
  return to_string(numerator)+"/"+to_string(denominator);
}

RationalNumber RationalNumber::addition( const RationalNumber &a )
 {// this code is given to you, use this to complete other operatations
 RationalNumber t;

 t.numerator = a.numerator * denominator;
 t.numerator += a.denominator * numerator;
 t.denominator = a.denominator * denominator;
 t.reduction();

 return t;
 }

 RationalNumber RationalNumber::subtraction( const RationalNumber &s ){
   RationalNumber t;
   t.numerator = s.denominator * numerator - s.numerator * denominator;
   t.denominator = s.denominator * denominator;
   t.reduction();
   return t;
 //complete this
 }

 RationalNumber RationalNumber::multiplication( const RationalNumber &m ) {
   RationalNumber t;
   t.numerator = m.numerator * numerator;
   t.denominator = m.denominator * denominator;
   t.reduction();
   return t;
 //complete this
 }

 RationalNumber RationalNumber::division( RationalNumber &v ) {
   RationalNumber t;
   if (v.numerator!= 0) {
    t.numerator = v.denominator * numerator;
    t.denominator = denominator * v.numerator;
    t.reduction();
  }
   else {
    cout << "Divide by zero error: terminating program" << endl;
    exit( 1 );
   }
  
   return t;
 //complete this
}


 RationalNumber RationalNumber::operator+( const RationalNumber &a )
 {
   //this code which overloads the + operator is given to you
   //use it to complete other overloaded operators 
 RationalNumber sum;

 sum.numerator = numerator * a.denominator + denominator * a.numerator;
 sum.denominator = denominator * a.denominator;
 sum.reduction();
 return sum;
 }

 RationalNumber RationalNumber::operator-( const RationalNumber &s ) {
   RationalNumber difference;
   difference.numerator = numerator * s.denominator - denominator * s.numerator;
   difference.denominator = denominator * s.denominator;
   difference.reduction();
   return difference;
 // complete
 }

 RationalNumber RationalNumber::operator*( const RationalNumber &m ) {
   RationalNumber product;
   product.numerator = m.numerator * numerator;
   product.denominator = m.denominator * denominator;
   product.reduction();
   return product;
 //complete
 }
RationalNumber RationalNumber::operator/( RationalNumber &d )
 {
   //this code is given to you please inspect it to see why its written this way
 RationalNumber divide;

 if ( d.numerator != 0 ) { // check for a zero in numerator
 divide.numerator = numerator * d.denominator;
 divide.denominator = denominator * d.numerator;
 divide.reduction();
 //cout<<"In divide "<<divide.toStringRationalNumber();
 
 }
 else {
 cout << "Divide by zero error: terminating program" << endl;
 exit( 1 ); // stdlib function
 }

 return divide;
 }

 bool RationalNumber::operator>( const RationalNumber &gr ) const
 {
   //this code is given to you
   
 if ( static_cast<double>( numerator ) / denominator >
 static_cast<double>( gr.numerator ) / gr.denominator )
 return true;
 else
 return false;
 }

 bool RationalNumber::operator<(const RationalNumber &lr) const
 {
    if ( static_cast<double>( numerator ) / denominator <
    static_cast<double>( lr.numerator ) / lr.denominator )
    return true;
    else
    return false;
// complete thtis
 }

 bool RationalNumber::operator>=( const RationalNumber &ger ) const
 { //code is givento you
   return *this == ger || *this > ger; }

 bool RationalNumber::operator<=( const RationalNumber &ler ) const { 
   return *this == ler || *this < ler;
   //complete this
}

 bool RationalNumber::operator==( const RationalNumber &er ) const {
   return numerator == er.numerator && denominator == er.denominator;
 //complete this
 }

 bool RationalNumber::operator!=( const RationalNumber &ner ) const
 { //given to you
   
   return !( *this == ner ); }

 std::string RationalNumber::toStringRationalNumber( ) const
 {
   //given to you
   
 if ( numerator == 0 ) // print fraction as zero
 //cout << numerator;
 return to_string(numerator);
 else if ( denominator == 1 ) // print fraction as integer
 return to_string(numerator);
 //cout << numerator;
 else
 //cout << numerator << '/' << denominator;
 return to_string(numerator)+"/"+to_string(denominator);
 }
 std::string RationalNumber::toStringRationalNumberAsDouble( ) const{
   //given to you
   return to_string(numerator*1.0/denominator);
 }
 void RationalNumber::reduction( void )
 {
   //given to you
 int largest, gcd = 1; // greatest common divisor;

 largest = ( numerator > denominator ) ? numerator: denominator;

 for ( int loop = 2; loop <= largest; ++loop )
 if ( numerator % loop == 0 && denominator % loop == 0 )

 gcd = loop;

 numerator /= gcd;
 denominator /= gcd;
// cout<<"In reduction "<<numerator <<" "<<denominator<<endl;
 }