
#include "Plane.h"

using namespace std;

int Plane::getAltitude() const {
  return altitude;
}

void Plane::setAltitude(int height) {
  this->altitude = height;
}

void Plane::addSpeed(int speed) {
  int maxSpeed = 1000;
  
  try {
    int newSpeed = getSpeed() + speed;
    if (newSpeed > maxSpeed) {
      throw "Over speed limit of 1000";
    }
    setSpeed(newSpeed);
  }
  catch (const char* msg) {
    std::cerr << msg << std::endl;
  }
}

string Plane::toString() {
  return getType() + " " + getModel() + " " + to_string(getYear()) + " Speed " + to_string(getSpeed());
}

string Plane::serveDrinks() {
  return "Water and Apple Juice Available";
}

  