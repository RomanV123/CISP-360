#pragma once
#include "Vehicle.h"

class Car: public Vehicle{

private:
  int wheelSize;
public:
  Car(){};
  Car(int year, int speed, string type, string model, int wheelSize): Vehicle(year,speed,type,model),wheelSize(wheelSize){};
   
  void addSpeed(int s) override;
  int getWheelSize();
  string toString() override;
  string serveDrinks() override;
  
};
