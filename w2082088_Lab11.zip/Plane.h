#pragma once
#include "Vehicle.h"
class Plane: public Vehicle{
  private:
  int altitude;

  public: 
    Plane(){};
    Plane(int year, int speed, string type, string model, int altitude): Vehicle(year,speed, type,model), altitude(altitude){};
    void addSpeed(int speed) override ;
    int getAltitude() const;
    void setAltitude(int height);
    string serveDrinks() override;
    string toString() override;
};