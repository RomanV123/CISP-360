#pragma once
#ifndef Vehicle_h
#define Vehicle_h
#include <string>
#include <iostream>
using namespace std;
class Vehicle{
private:
  int year;
  int speed;
  string type;
  string model;
public:
Vehicle();
Vehicle(int year, int speed, string type, string model);
  void setSpeed(int speed);
  void setYear(int year);
  void setModel(string model);
  void setType(string type);
  int getSpeed()const;
  int getYear();
  string getType();
  string getModel();
  virtual void addSpeed(int s) ;
  virtual string toString();
  virtual string serveDrinks();

  virtual ~Vehicle() = default;

};
#endif