#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include<memory>
#include <cstdlib>//for exit
#include "BankAccount.h"  //bad practice to include cpp files

using namespace std;
using std::cout;
using std::string;
using std::istringstream;
using std::cin;
using std::vector;
using std::ifstream;
using std::shared_ptr;
using std::make_shared;

const int SIZE = 10;

int fillVector (vector<shared_ptr<BankAccount>>& accountsVector, string filename);
int largest(vector<shared_ptr<BankAccount>> &accountsVector);
int smallest(vector<shared_ptr<BankAccount>> &accountsVector);
void printVector(vector<shared_ptr<BankAccount>>&accountsVector);
void checkDuplicates(vector<shared_ptr<BankAccount>> &accountsVector);
void insertAccounts(vector<shared_ptr<BankAccount>> &accountsVector);
void printCounts(vector<shared_ptr<BankAccount>>& accountsVector);


int main() {
  vector<shared_ptr<BankAccount>> accountsVector;
  int count = fillVector(accountsVector, "C:/Users/roman/OneDrive/Desktop/BankData.txt");

  printVector(accountsVector);
  cout << "_____________________________" << endl;
  largest(accountsVector);
  cout << endl;
  smallest(accountsVector);
  cout << "_____________________________" << endl;
  printCounts(accountsVector);
  checkDuplicates(accountsVector);                                                    //checks for duplicates

  printCounts(accountsVector);

  insertAccounts(accountsVector);                                              //inserts accounts

  printVector(accountsVector);                                                 //reprints the vector
  printCounts(accountsVector);

  
  /*************************************************************/
  
  //This is the code below I was using before that was giving me errors and crashing my program. My program would crash when I would delete the ! from (!input) to make it (input). Could you happen to explain why in the comments?
  
  /*try {
      
      ifstream input("C:/Users/roman/OneDrive/Desktop/BankData.txt");   
      if (!input) {
          std::cout << " File Open\n";
    
    fillVector(input,accountsVector);
    int getCount();
    //getCount using vector size
    printVector(accountsVector);
    
    cout<<"Largest Balance: "<<endl;
    cout<<accountsVector[largest(accountsVector)]->toString()<<endl;
    cout<<"Smallest Balance :"<<endl;
    cout<<accountsVector[smallest(accountsVector)]->toString()<<endl;
    cout<<"Using the static count, there are "<<BankAccount::count<< " accounts"<<endl;
    cout<<"Using vector size, there are "<<accountsVector.size()<< " accounts"<<endl;
    
    checkDuplicates(accountsVector);
    cout<<"Using the static count, there are "<<BankAccount::count<< " accounts"<<endl;
     cout<<"Using vector size, there are "<<accountsVector.size()<< " accounts"<<endl;
     insertAccounts(accountsVector);
     cout<<"\nInserted Three New Accounts: Reprinting List \n" <<endl;
     printVector(accountsVector);
      cout<<"Using the static count, there are "<<BankAccount::count<< " accounts"<<endl;
     cout<<"Using vector size, there are "<<accountsVector.size()<< " accounts"<<endl;
    
  }
  else 
     throw string("File Open Error");
}
catch (string message){
   cout<<message<<endl;
   exit(0);
}*/
}
void checkDuplicates(vector<shared_ptr<BankAccount>>& accountsVector)
{
    bool dup = false;

    for (int i = 0; i < accountsVector.size(); i++) {

        for (int j = i + 1; j < accountsVector.size(); j++) {

            if (accountsVector[i]->equals(accountsVector[j])) {

                accountsVector.erase(accountsVector.begin() + j);
                --j;

                dup = true;

            }
        }

    }

    if (dup) {

        cout << "\n";
        cout << "Duplicate Accounts Found:: Reprinting the List \n";
        printVector(accountsVector);                                               //reprints the array

    }

    cout << "\n";
}
  
   
int fillVector(vector<shared_ptr<BankAccount>>& accountsVector, string filename)

{
    ifstream inputFile(filename);
    istringstream instream;
    string data;
    int count = 0;

    string accountName, lastName, firstName;
    int id, accountNumber;                             //variables
    double accountBalance;

    try {
        if (inputFile) {
            while (!inputFile.eof() && count < SIZE) {
                getline(inputFile, data);
                istringstream instream(data);
                instream >> firstName;
                instream >> lastName;
                instream >> id;
                instream >> accountNumber;
                instream >> accountBalance;
                accountName = firstName + " " + lastName;

                shared_ptr<BankAccount> bankAccount = make_shared<BankAccount>(accountName, id, accountNumber, accountBalance);    //"temp" shared pointer that will push back into vector
                accountsVector.push_back(bankAccount);                                                                           

                count++;

            }

        }
        else throw string("File Not Open");
    }
    catch (string message) {
        cout << message << "\n";
        exit(0);
    }
    return count;
}
//presumes that negative balances will not be there
int largest(vector<shared_ptr<BankAccount>> &accountsVector)
{
    double largest = 0;
    int index = 0;

    for (int i = 0; i < accountsVector.size(); i++) {

        if (accountsVector[i]->getAccountBalance() > largest) {

            largest = accountsVector[i]->getAccountBalance();              //for loop that checks through the array

            index = i;
        }
    }

    cout << "The Largest Account Balance \n";                                   //finds the account with the largest account balance
    cout << accountsVector[index]->toString();

    return largest;
}
int smallest(vector<shared_ptr<BankAccount>>& accountsVector)
{
    double smallest = accountsVector[0]->getAccountBalance();
    int index = 0;

    for (int i = 0; i < accountsVector.size(); i++) {
        if (accountsVector[i]->getAccountBalance() < smallest) {     //for looop

            smallest = accountsVector[i]->getAccountBalance();
            index = i;
        }
    }

    cout << "The Lowest Account Balance \n";                                    //finds the account with the lowest account balance
    cout << accountsVector[index]->toString();

    return smallest;
}

void printVector(vector<shared_ptr<BankAccount>>  &accountsVector){
   cout<<"FAVORITE BANK - CUSTOMER DETAILS "<<endl;
   cout<<"--------------------------------"<<endl;
   auto iter = accountsVector.begin();
   for (iter = accountsVector.begin();iter<accountsVector.end();iter++)
   
       cout<<(*iter)->toString()<<endl;
//use iterator
}   

void insertAccounts(vector<shared_ptr<BankAccount>>& accountsVector) {

    accountsVector.insert(accountsVector.begin() + 2, make_shared<BankAccount>("Amy Machado", 387623, 1244, 1023.67));
    accountsVector.insert(accountsVector.begin() + 4, make_shared<BankAccount>("Tak Phen", 981243, 1262, 6423.03));            //inserts new accounts into the vector
    accountsVector.insert(accountsVector.begin() + 6, make_shared<BankAccount>("Celia Beatle", 465281, 1276, 3.56));           //using the insert function

    cout << "\n";
    cout << "Inserted Three New Accounts: Reprinting List \n";
}

void printCounts(vector<shared_ptr<BankAccount>>& accountsVector) {

    cout << "Using the static count, there are " << BankAccount::getCount() << " accounts \n";       //displays the counts of the vector one more time
    cout << "Using vector size, there are " << accountsVector.size() << " accounts \n";

}