#include <string>
#include <iostream>
#include "BankAccountHeader.h"
#include "BankHeader.h"

// implement all the Bank Account methods given in the class header
 
const double BankAccount::MIN_BALANCE = 9.99;
const double BankAccount::MIN_REWARD_AMOUNT = 1000.0;
const double BankAccount::REWARD_RATE = 0.04;
int  BankAccount::count = 0;

// Default constructor
BankAccount::BankAccount() {
    accountNumber = 0;
    id = 0;
    accountName = "";
    accountBalance = MIN_BALANCE;
    count++;
}

// Custom constructor
BankAccount::BankAccount(std::string accountName, int id, int accountNumber, double accountBalance) {
    this->accountName = accountName;
    this->id = id;
    this->accountNumber = accountNumber;
    this->accountBalance = accountBalance;
    count++;
}

// Getter methods
std::string BankAccount::getAccountName() {
    return accountName;
}

int BankAccount::getAccountNumber() {
    return accountNumber;
}

double BankAccount::getAccountBalance() {
    return accountBalance;
}

// Setter method for account balance
void BankAccount::setAccountBalance(double accountBalance) {
    this->accountBalance = accountBalance;
}

// Helper function to add reward to the account
void BankAccount::addReward(double amount) {
    accountBalance += amount;
}

// Function to get account ID
int BankAccount::getId() {
    return id;
}

// Function to convert the account information to a string
std::string BankAccount::toString() {

    
    return "Account Name: " + accountName + "\n"
        + "Account Number: " + std::to_string(accountNumber) + "\n"
        + "Account Balance: $" + std::to_string(accountBalance) + "\n";
}

// Function to withdraw an amount from the account
bool BankAccount::withdraw(double amount) {
    if (accountBalance - amount >= MIN_BALANCE) {
        accountBalance -= amount;
        return true;
    }
    else {
        std::cout << std::endl;
        std::cout << "Insufficient Funds" << endl;


        return false;

    }
    
}

// Function to deposit an amount into the account
void BankAccount::deposit(double amount) {

    accountBalance += amount;
    if (amount > MIN_REWARD_AMOUNT) {
        addReward(amount);
    }
}



// Function to check if two bank accounts are equal
bool BankAccount::equals(BankAccount other) {
    return (id == other.id) && (accountNumber == other.accountNumber);
}

// Function to get the count of existing bank accounts
int BankAccount::getCount() {
    return count;
}