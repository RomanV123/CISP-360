#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <cstdlib>//for exit
#include "BankAccountHeader.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::istringstream;
using std::ifstream;
using std::vector;
using std::shared_ptr;
using std::make_shared;

class Bank{
private:
  std::shared_ptr<BankAccount> bptr;
  std::vector<std::shared_ptr<BankAccount>> accountsVector;
public:
	string secondGetAccountName(); //find the account namew
	int secondGetAccountNumber();
	double secondGetAmount();
	int binarySearch(vector<shared_ptr<BankAccount>>& accountVector, int accountNumber, string accountName);
//constructor that reads bank database from file
//it calls the fillVector method to populate the database
Bank(std::string filename);
//withdraw amount
void withdraw();
//check balance
void viewBalance();
//deposit amount
void deposit();
//helper function
void fillVector (std::ifstream &input,std::vector<std::shared_ptr<BankAccount>> &accountsVector);
//admin function print all accounts
void printVector(std::vector<std::shared_ptr<BankAccount>> &accountsVector);
//sort accounts
void sort(std::vector<std::shared_ptr<BankAccount>> &accountsVector);


};