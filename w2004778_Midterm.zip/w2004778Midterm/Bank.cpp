#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <cstdlib>//for exit
#include "BankHeader.h"
#include "BankAccountHeader.h"
using namespace std;

string Bank::secondGetAccountName() {

    string fName, lName;
    cout << "What is the Account First Name: ";
    cin >> fName;
    cout << "What is the Account Last Name: ";
    cin >> lName;

    return fName + ", " + lName;
}

int Bank::secondGetAccountNumber() {
    int number;
    cout << "What is the Account Number: ";
    cin >> number;
    return number;
}

double Bank::secondGetAmount() {
    double number;
    cout << "What is the Dollar Amount: ";
    cin >> number;

    return number;
}

int Bank::binarySearch(vector<shared_ptr<BankAccount>>& accountsVector, int accountNumber, string accountName) {

    int first, middle, last;
    first = 0; last = accountsVector.size();
    middle = (first + last) / 2;


    while (first <= last) {
        if (accountsVector[middle]->getAccountName() == accountName && accountsVector[middle]->getAccountNumber() == accountNumber)
            return middle;
        else {
            if (accountsVector[middle]->getAccountNumber() < accountNumber)
                first = middle + 1;
            else last = middle - 1;
        }
        middle = (first + last) / 2;
    }
    return -1;

}

Bank::Bank(string fileName) {


    ifstream inputFile(fileName);
    fillVector(inputFile, accountsVector);

    sort(accountsVector);
    printVector(accountsVector);

}

// Helper function to read data from the input stream and populate the accountsVector
void Bank::fillVector(std::ifstream& input, std::vector<std::shared_ptr<BankAccount>>& accountsVector) {
    string fname, lname;
    string name;
    string data;
    int num, id;
    double balance;
    istringstream instream;

    try {
        if (input) {
            while (!input.eof()) {
                getline(input, data);
                istringstream instream(data);
                instream >> fname;
                instream >> lname;
                instream >> id;
                instream >> num;
                instream >> balance;

                name = fname + ", " + lname;
                shared_ptr<BankAccount> temp = make_shared <BankAccount>(name, id, num, balance);
                accountsVector.push_back(temp);
            }
        }
        else throw string("File not found");
    }
    catch (string message) {
        cout << message << endl;
        exit(0);
    }
    
}
// Admin function to print information about all accounts
void Bank::printVector(std::vector<std::shared_ptr<BankAccount>>& accountsVector) {
    for (const auto& account : accountsVector) {
        std::cout << account->toString() << std::endl;
    }
}

// Method to withdraw an amount from the currently selected bank account
void Bank::withdraw() {
    string tempName = secondGetAccountName();
    int tempNumber = secondGetAccountNumber();
    int index = binarySearch(accountsVector, tempNumber, tempName);
    if (index >= 0) {
        double temp = secondGetAmount();
        accountsVector[index]->withdraw(temp);


       
        cout << accountsVector[index]->toString();
       


    }

    else {
        cout << "Account was not found " << endl;
    }



}

// Method to check the balance of the currently selected bank account
void Bank::viewBalance() {

    string tempName = secondGetAccountName();
    int tempNumber = secondGetAccountNumber();

    int index = binarySearch(accountsVector, tempNumber, tempName);
    if (index >= 0) {

        
        cout << accountsVector[index]->toString();
       


    }
    else {
        cout << "Account was not found \n";
    }
}

// Method to deposit an amount into the currently selected bank account
void Bank::deposit() {

    string tempName = secondGetAccountName();
    int tempNumber = secondGetAccountNumber();

    int index = binarySearch(accountsVector, tempNumber, tempName);
    if (index >= 0) {


        double temp = secondGetAmount();
        accountsVector[index]->deposit(temp);

        
        cout << accountsVector[index]->toString();
       


    }
    else {
        cout << "Account was not found \n";
    }

}




// Method to sort the accounts within the accountsVector
void Bank::sort(vector<shared_ptr<BankAccount>>& accountVector) {

    if (accountVector.size() > 1) {
        shared_ptr<BankAccount> temp;
        for (int i = 0; i < accountsVector.size() - 1; i++) {
            for (int j = 0; j < accountsVector.size() - i - 1; j++) {
                if ((accountsVector[j]->getAccountNumber()) > (accountsVector[j + 1]->getAccountNumber())) {
                    temp = accountsVector[j];
                    accountsVector[j] = accountsVector[j + 1];
                    accountsVector[j + 1] = temp;
                }
            }
        }
    }
}