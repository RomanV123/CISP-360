//Roman Vasilyev
#pragma once
#include "Package.h"

class OvernightPackage : public  Package
{
private: 
    double overnightFee;

public:
    OvernightPackage()
    {                                                // Constructors (in-line for simplicity)
        overnightFee = 0;
    }
    OvernightPackage(std::string n, std::string a, std::string c, std::string s, std::string z, double w, double cp, double fee) : Package(n, a, c, s, z, w, cp)
    {
        overnightFee = fee;
    }

    double getOvernightFee();                                           // Returns overnight fee

    double calculateOvernightFee();                                     // Calculate the  overnight fee
    double calculateCost();                                             // Call base class for standard calculateCost method then add overnight fee cost

    std::string toString();                                             // Returns the string version of the overnight package
};
