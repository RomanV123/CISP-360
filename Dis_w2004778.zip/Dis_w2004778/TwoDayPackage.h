//Roman Vasilyev
#include "Package.h"

class TwoDayPackage : public Package
{
private:
    double flatFee;

public:
    TwoDayPackage()
    {
        // In-line constructors
        flatFee = 0;
    }
    TwoDayPackage(std::string n, std::string a, std::string c, std::string s, std::string z, double w, double cp, double fee): Package(n, a, c, s, z, w, cp)
    {
        flatFee = fee;
    }
    
    double calculateCost();                                             // Calculates the total cost. standard fee is added to flat fee
    std::string toString();                                             // Returns the string version
    
    double getFlatFee();                                                // Return flat fee
};
