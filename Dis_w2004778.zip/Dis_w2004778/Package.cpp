//Roman Vasilyev
#include "Package.h"

// Default constructor
Package::Package()
{
    name = "";
    address = "";
    city = "";
    state = "";
    ZIP = "";
    weight_in_ounce = 0;
    cost_per_ounce = 0;
}
// Custom constructor
Package::Package(std::string n, std::string a, std::string c,
    std::string s, std::string z, double w, double cp)
{
    name = n;
    address = a;
    city = c;
    state = s;
    ZIP = z;
    weight_in_ounce = w;
    cost_per_ounce = cp;
}

// Gets package name
std::string Package::getName()
{
    return name;
}
// Gets package address
std::string Package::getAddress()
{
    return address;
}

// Gets package ZIP
std::string Package::getZIP()
{
    return ZIP;
}
// Gets package cost per ounce
double Package::getCost_per_ounce()
{
    return cost_per_ounce;
}
// Gets package weight in ounces
double Package::getWeight_in_ounce()
{
    return weight_in_ounce;
}
// Gets package city
std::string Package::getCity()
{
    return city;
}
// Gets package state
std::string Package::getState()
{
    return state;
}
// Converts a decimal number to a string with two places after the decimal
std::string Package::processNumber(double cost)
{
    std::string sixPlacesAfterDecimal = std::to_string(((int)(cost * 100)) / 100.0);
    int pos = sixPlacesAfterDecimal.find('.');
    std::string twoPlacesAfterDecimal = sixPlacesAfterDecimal.substr(0, pos + 3);
    return twoPlacesAfterDecimal;
}

// Displays package info
std::string Package::toString()
{
    return "Name: " + name + " Address: " + address + " City: " + city + " State: " + state + " ZIP: " + ZIP + 
        "\nWeight (oz) " + processNumber(weight_in_ounce) + " Cost of Shipping per ounce " + processNumber(cost_per_ounce) + 
        "\nTotal Basic Shipping cost $" + processNumber(calculateCost()) + "\n";
}

// Calculates standard cost of shipping by multiplying weight in ounces with cost per ounce
double Package::calculateCost()
{
    return weight_in_ounce * cost_per_ounce;
}
