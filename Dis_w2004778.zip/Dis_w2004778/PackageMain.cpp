//Roman Vasilyev
#include "TwoDayPackage.h"
#include "OvernightPackage.h"

int main(){
    //3 shared pointers to packages with same wieght in oz but different recipients

    // Cost per oz to ship = $0.67. Std package weightis 3.75 oz
    std::shared_ptr<Package> p1 = std::make_shared< Package>
        ("John Smith", "1020 Orange St", "Lakeland", "FL", "92317", 3.75, 0.67);
    std::cout << p1->toString();

    //Standard cost per oz to ship = $0.67. Two day flat fee = $3.50  Two day package weight 3.75 oz.
    std::shared_ptr<TwoDayPackage> td1 = std::make_shared<TwoDayPackage>
        ("Bob George", "21 Pine Rd", "Cambridge", "MA", "429024", 3.75, 0.67, 3.5);
    std::cout << "\n" << td1->toString();

    //Standard cost per oz to ship = $0.67. Overnight fee 0.45. Overnight package weight 3.75 oz. 
    std::shared_ptr<OvernightPackage> on1 = std::make_shared<OvernightPackage>
        ("Don Kelly", "9 Main St", "Denver", "CO", "66456", 3.75, 0.67, 0.45);
    std::cout << "\n" << on1->toString();
}
