//Roman Vasilyev
#pragma once
#include <iostream>
#include <string>
#include <memory>
#include <cmath>

class Package
{
private:
    std::string name;
    std::string address;
    std::string city;
    std::string state;
    std::string ZIP;
    double weight_in_ounce;
    double cost_per_ounce;

public: 
    Package();
    // Constructors
    Package(std::string n, std::string a, std::string c,
        std::string s, std::string z, double w, double cp);

    // Getters
    std::string getName();
    std::string getAddress();
    std::string getCity();
    std::string getState();
    std::string getZIP();
    double getCost_per_ounce();
    double getWeight_in_ounce();

    std::string toString();
    // Returns string version of Package details
    
    std::string processNumber(double cost);
    //method converts decimal num to string text

    double calculateCost();
    // Calculates standard shipping cost for package

};
