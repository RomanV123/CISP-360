//Roman Vasilyev
#include "OvernightPackage.h"

// Return overnight fee
double OvernightPackage::getOvernightFee()
{
    return overnightFee;
}

// Return the string represention of the overnight package
std::string OvernightPackage::toString()
{
    return Package::toString() + "Add Overnight Fee per oz: " + processNumber(overnightFee) +
        "\nTotal Overnight Shipping Fee cost $" + processNumber(calculateCost()) + "\n";
}

// Calculates overnight fee by multiplying weight in ounces with the overnight fee cost
double OvernightPackage::calculateOvernightFee()
{
    return Package::getWeight_in_ounce() * overnightFee;
}
// Calls the base class standard calculateCost method and adds the overnight fee cost
double OvernightPackage::calculateCost()
{
    return Package::calculateCost() + calculateOvernightFee();
}
