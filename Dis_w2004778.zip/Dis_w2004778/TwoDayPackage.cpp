//Roman Vasilyev
#include "TwoDayPackage.h"

// Calculates total cost by adding flat fee to standard shipping
double TwoDayPackage::calculateCost()
{
    return flatFee + Package::calculateCost();
}
// Return the string represention of the two day package
std::string TwoDayPackage::toString()
{
    return Package::toString() + "Add Flat Two Day Fee: " + processNumber(flatFee) + 
        "\nTotal TwoDay Shipping Fee cost $" + processNumber(calculateCost()) + "\n";
}

// Return the flat fee
double TwoDayPackage::getFlatFee()
{
    return flatFee;
}
