#include "Circle.h"
#include <fstream>
#include <sstream>
#include "Painting.h"

   Painting::Painting(){
    
   }
 
   //regular constructor
   Painting::Painting(string filename){
     ifstream inputFile(filename);
  istringstream instream;
  string data;
  int count =0;
  int x,y,radius;
  try{
  if (inputFile){
    while (!inputFile.eof()){
      getline(inputFile,data);
       istringstream instream(data);
       instream>>x;
       instream>>y;
       instream>>radius;
       shared_ptr<Circle> circle = make_shared<Circle>(x,y,radius);
       paintingVector.push_back(circle); 
       count++;    
  
    }
    
   }
    else throw string("File Not Found");
  }
  catch (string message){
    cout<<message<<endl;
    exit(0);
  }
}
 

//returns a circle at the given index in the painting vector
shared_ptr<Circle> Painting::getCircle(int index) const{
  return paintingVector[index];
}
//gets the size of the painting vector
int Painting::getSize()const{
  return paintingVector.size();
}
//copy constructor for the Painting Class
Painting::Painting(const Painting& other) {
    // Copy individual circles from 'other' to this painting
    for (const shared_ptr<Circle>& circlePtr : other.paintingVector) {
        // Create a deep copy of the Circle and add it to the current painting's vector
        shared_ptr<Circle> copiedCircle = make_shared<Circle>(*circlePtr);
        paintingVector.push_back(copiedCircle);
    }
}
 

  
//returns a string containing the painting vector
string Painting::toString() {
    string result = "[";  // Start with an opening bracket.

    // Iterate through the paintingVector and concatenate the string representation of each circle.
    for (const shared_ptr<Circle>& circlePtr : paintingVector) {
        result += circlePtr->toString();  // Assuming Circle has a `toString` method.
        result += " ";  // Separate each circle with a space.
    }

    // Remove the trailing space, if there are circles in the vector.
    if (!paintingVector.empty()) {
        result.pop_back();
    }

    result += "]";  // Add a closing bracket.

    return result;
}

void Painting::setRadius(int index,int radius ){
  paintingVector[index]->setRadius(radius);
}
Painting::~Painting(){
    //delete paintingVector;
}
