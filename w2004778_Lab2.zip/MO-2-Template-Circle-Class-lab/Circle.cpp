#define _USE_MATH_DEFINES
#include <math.h>
#include <string>
#include "CircleHeader.h"


// Default constructor
Circle::Circle() {
    x = y = 0;
    radius = 1;
    // Creates a unit circle with the center at the origin
}

// Regular constructor
Circle::Circle(int xcoord, int ycoord, int r) : x(xcoord), y(ycoord), radius(r) {
}

int Circle::getX() {
    return x;
}

int Circle::getY() {
    return y;
}

int Circle::getRadius() {
    return radius;
}

double Circle::getArea() {
    return M_PI * radius * radius;
}

double Circle::getCircumference() {
    return 2 * M_PI * radius;
}

std::string Circle::toString() {
    return "(" + std::to_string(x) + ", " + std::to_string(y) + "), Radius: " + std::to_string(radius);
}
