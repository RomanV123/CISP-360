#include <string>
#include <iostream>
#include <iomanip>
#include "CircleHeader.h"


int main() {
    Circle circleOne;
    std::cout << "Created circleOne: " << circleOne.toString() << std::endl;

    Circle circleTwo(0, 0, 4);
    std::cout << "Created circleTwo: " << circleTwo.toString() << std::endl;

    Circle circleThree(-2, -9, 6);
    std::cout << "Created circleThree: " << circleThree.toString() << std::endl;

    // Print the circumference and area of each circle
    std::cout << "CircleOne Circumference: " << std::fixed << std::setprecision(2) << circleOne.getCircumference() << std::endl;
    std::cout << "CircleOne Area: " << std::fixed << std::setprecision(2) << circleOne.getArea() << std::endl;

    std::cout << "CircleTwo Circumference: " << std::fixed << std::setprecision(2) << circleTwo.getCircumference() << std::endl;
    std::cout << "CircleTwo Area: " << std::fixed << std::setprecision(2) << circleTwo.getArea() << std::endl;

    std::cout << "CircleThree Circumference: " << std::fixed << std::setprecision(2) << circleThree.getCircumference() << std::endl;
    std::cout << "CircleThree Area: " << std::fixed << std::setprecision(2) << circleThree.getArea() << std::endl;

    return 0;
}
