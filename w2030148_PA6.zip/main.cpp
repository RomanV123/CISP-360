//Name: Ethan Tan
//Date: 29 August 2023
/*******************************
This Assignment works on the past 
assignments so far and will build
on the topic of shared pointers to
objects and vectors.
*******************************/

#include "BankAccount.h"
#include<iostream>
#include <fstream>
#include <vector>
#include <memory>
#include<cstdlib>
#include <fstream>
#include <sstream>

using std::cout;
using std::string;
using std::istringstream;
using std::cin;
using std::vector;
using std::ifstream;
using std::shared_ptr;
using std::make_shared;

const int SIZE = 10;

int inputData(vector<shared_ptr<BankAccount>>& accountVector, string filename);
void checkDup(vector<shared_ptr<BankAccount>> &accountVector);
void largest(vector<shared_ptr<BankAccount>> &accountVector);                            //protocols
void lowest(vector<shared_ptr<BankAccount>> &accountVector);
void printVector(vector<shared_ptr<BankAccount>> &accountVector);
void insertAccounts(vector<shared_ptr<BankAccount>> &accountVector);
void printCounts(vector<shared_ptr<BankAccount>>& accountVector);


int main() {

    vector<shared_ptr<BankAccount>> accountVector;                              //creates Vector of Shared Pointers of the object BankAccount
    int count = inputData(accountVector, "c://temp//BankData.txt");             //reads from data file to start program


    printVector(accountVector);                                                 //prints out the initial array

    cout << "---------------------------------- \n";
    largest(accountVector);                                                     //largest function was made into void module, to make main
    cout << "\n";                                                               //look more simple and "cleaner"
    lowest(accountVector);
    cout << "---------------------------------- \n";

    printCounts(accountVector);

    checkDup(accountVector);                                                    //checks for dups

    printCounts(accountVector);
   
    insertAccounts(accountVector);                                              //inserts accounts
   
    printVector(accountVector);                                                 //reprints the vector
    printCounts(accountVector);

}

//function that will read data from file
int inputData(vector<shared_ptr<BankAccount>>& accountVector, string filename)

{
    ifstream inputFile(filename);
    istringstream instream;
    string data;
    int count = 0;

    string accountName, lastName, firstName;
    int id, accountNum;                             //variables
    double accountBalance;

    try {
        if (inputFile) {
            while (!inputFile.eof() && count < SIZE) {
                getline(inputFile, data);
                istringstream instream(data);
                instream >> firstName;
                instream >> lastName;
                instream >> id;
                instream >> accountNum;
                instream >> accountBalance;
                accountName = firstName + " " + lastName;

                shared_ptr<BankAccount> bankAccount = make_shared<BankAccount>(accountName, id, accountNum, accountBalance);    //"temp" shared pointer that will 
                accountVector.push_back(bankAccount);                                                                           //be pushed backed into the vector

                count++;

            }

        }
        else throw string("File Not Found");
    }
    catch (string message) {
        cout << message << "\n";
        exit(0);
    }
    return count;
}


//checks to see if there are duplicates in the file, checking for the name and id
void checkDup(vector<shared_ptr<BankAccount>> &accountVector)
{
    bool dup = false;

    for (int i = 0; i < accountVector.size(); i++) {

        for (int j = i + 1; j < accountVector.size(); j++) {

            if (accountVector[i]->equals(accountVector[j])) {

                accountVector.erase(accountVector.begin() + j);
                --j;

                dup = true;

            }
        }

    }

    if (dup) {

        cout << "\n";
        cout << "Duplicate Accounts Found:: Reprinting the List \n";
        printVector(accountVector);                                               //reprints the array

    }

    cout << "\n";
}

//module that checks for the largest balance
void largest(vector<shared_ptr<BankAccount>> &accountVector)
{
    double largest = 0;
    int index = 0;

    for (int i = 0; i < accountVector.size(); i++) {

        if (accountVector[i]->getAccountBalance() > largest) {

            largest = accountVector[i]->getAccountBalance();              //for loop that checks through the array

            index = i;
        }
    }

    cout << "The Largest Account Balance \n";                                   //finds the account with the largest account balance
    cout << accountVector[index]->toString();

          
}

//module that checks for the lowest balance
void lowest(vector<shared_ptr<BankAccount>> &accountVector)
{
    double lowest = accountVector[0]->getAccountBalance();
    int index = 0;

    for (int i = 0; i < accountVector.size(); i++) {
        if (accountVector[i]->getAccountBalance() < lowest) {     //for looop

            lowest = accountVector[i]->getAccountBalance();
            index = i;
        }
    }

    cout << "The Lowest Account Balance \n";                                    //finds the account with the lowest account balance
    cout << accountVector[index]->toString();

        
}


//prints out the array
void printVector(vector<shared_ptr<BankAccount>> &accountVector)
{
    cout << "FAVORITE BANK - CUSTOMER DETAILS \n";
    cout << "--------------------------------- \n";

    for (int i = 0; i < accountVector.size(); i++) {
        cout << accountVector[i]->toString() << "\n";


    }

}

void insertAccounts(vector<shared_ptr<BankAccount>> &accountVector) {

    accountVector.insert(accountVector.begin() + 2, make_shared<BankAccount>("Amy Machado", 387623, 1244, 1023.67));
    accountVector.insert(accountVector.begin() + 4, make_shared<BankAccount>("Tak Phen", 981243, 1262, 6423.03));            //inserts new accounts into the vector
    accountVector.insert(accountVector.begin() + 6, make_shared<BankAccount>("Celia Beatle", 465281, 1276, 3.56));           //using the insert function

    cout << "\n";
    cout << "Inserted Three New Accounts: Reprinting List \n";
}

void printCounts(vector<shared_ptr<BankAccount>>& accountVector) {

    cout << "Using the static count, there are " << BankAccount::getCount() << " accounts \n";       //displays the counts of the vector one more time
    cout << "Using vector size, there are " << accountVector.size() << " accounts \n";

}