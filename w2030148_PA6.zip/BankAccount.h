//Name: Ethan Tan
//Date: 29 August 2023/
//Header Module using class

#include<iostream>
#include <fstream>
#include <vector>
#include <memory>
#include<cstdlib>
#include <fstream>
#include <sstream>

using std::cout;
using std::string;
using std::istringstream;
using std::cin;
using std::vector;
using std::ifstream;
using std::shared_ptr;
using std::make_shared;

const double MIN_BALANCE = 9.99;
const double REWARDS_AMOUNT = 1000.00;          //constants that will be used through the code, these can be changed
const double REWARDS_RATE = 1.04;

class BankAccount {                             //bank account class with private and public  
private:


    std::string accountName;
    int accountID;
    int accountNum;
    double accountBalance;



public:
    BankAccount();
    BankAccount(string accountName, int ID, int accountNum, double accountBalance);
    double getAccountBalance();
    std::string getAccountName();
    int getAccountNum();
    int getAccountID();
    static int getCount();
    void setAccountBalace(double amount);               //public bank account modules that will be used
    bool withdraw(double amount);
    void deposit(double amount);
    void addRewards(double amount);
    std::string toString();
    bool equals(shared_ptr<BankAccount> accountVector);



};




