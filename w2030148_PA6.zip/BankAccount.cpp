#include "BankAccount.h"
#include<iostream>
#include <fstream>
#include <vector>
#include <memory>
#include<cstdlib>
#include <fstream>
#include <sstream>
#include <iomanip>

using std::cout;
using std::string;
using std::istringstream;
using std::cin;
using std::vector;
using std::ifstream;
using std::shared_ptr;
using std::make_shared;

//default constructor that sets the account number and balance to 0
static int count = 0;

BankAccount::BankAccount() {

    accountName = "";
    accountID = 0;
    accountNum = 0;
    accountBalance = 0;
    
}

//Constructor 

BankAccount::BankAccount(std::string xaccountName, int xID, int xaccountNum, double xaccountBalance) :
    accountName(xaccountName), accountID(xID), accountNum(xaccountNum), accountBalance(xaccountBalance) {

    accountID = xID;
    accountName = xaccountName;
    accountNum = xaccountNum;
    accountBalance = xaccountBalance;
    count++;
}

//gets the account balance and returns it
double BankAccount::getAccountBalance() {

    return accountBalance;
}

//gets account name and returns it
std::string BankAccount::getAccountName() {

    return accountName;
}

//gets account num and returns it
int BankAccount::getAccountNum() {

    return accountNum;
}

//gets the account ID and returns it
int BankAccount::getAccountID() {

    return accountID;

}

int BankAccount::getCount() {

    return count;
}

//sets account balance
void BankAccount::setAccountBalace(double accountBalance) {

    accountBalance = accountBalance;

}

//does withdraw math
bool BankAccount::withdraw(double amount) {



    if (accountBalance < MIN_BALANCE) {

        std::cout << accountName << ": " << std::endl;
        std::cout << "Insufficient Funds!" << std::endl;        // sees if the account balance first is capable
        std::cout << std::endl;                                 // of doing withdraw, if not it comes out with 
        // insufficient funds

        return true;

    }

    else {                                                      //else statement will then remove the money from
        //the account and display the remaining balance
        accountBalance -= amount;
        std::cout << accountName << ": " << std::endl;
        std::cout << "Remaining Balance: " << accountBalance << std::endl;;
        std::cout << std::endl;

        return false;

    }

}

void BankAccount::deposit(double amount) {

    if (amount <= REWARDS_AMOUNT) {                 //Deposit module that will add the amount to the account
        //if the amount is less than the rewards amount, then the 
        accountBalance += amount;                   //amount will just be added into the accountbalance

    }

    else {

        addRewards(amount);                         //if the amount is more than the rewards amount, it will 
        //call the addrewards module
    }
}

void BankAccount::addRewards(double amount) {

    accountBalance += REWARDS_RATE * amount;        //add rewards module that will add the rewards rate to the account

}

std::string BankAccount::toString() {

    std::cout << std::fixed << std::setprecision(2);        //to string module that will display everything

    return "Account Name: " + (accountName)+"\n" + "Account Number: " + std::to_string(accountNum).substr(0, 4) + "\n" + "Account Balance: $" + std::to_string(accountBalance).substr(0, std::to_string(accountBalance).find(".") + 3) + "\n";

}

//module that will see if 2 accounts read from the file are equal to each other
//if it finds accounts, then it will set that account to true
bool BankAccount::equals(shared_ptr<BankAccount> other) {

    if ((accountName == other->getAccountName()) && (accountID == other->getAccountID())) {
        return true;

    }

    else {
        return false;

    }

}