#include<iostream>
#include "Circle.h"
#include <fstream>
#include <vector>
#include<cstdlib>

#include <fstream>
#include <sstream>

//note that vectors have to be passed by reference
//opens the file using try catch
//if open fails, throw an exception and exit the program
//other wise populate read the data line by line from the data file
//create a new Circle with this data
//push this circle back onto the vector

void inputData(vector<Circle> &circleVector, string filename){
  ifstream inputFile(filename);
  istringstream instream;
  string data;
  int x,y,radius;
  try{
  if (inputFile){
    while (!inputFile.eof()){
      getline(inputFile,data);
       istringstream instream(data);
       instream>>x;
       instream>>y;
       instream>>radius;
       Circle circle(x,y,radius);
       circleVector.push_back(circle);    
  
    }

  }
  else throw string("File Not Found");
  }
  catch (string message){
    cout<<message<<endl;
    exit(0);
  }

}

int main() {
    //create a vector of circles
    vector<Circle> circleVector;

    //open the data file and populate the vector
    inputData(circleVector, "c:/temp/dataLab4.txt");

    vector<Circle>::iterator iter;
    cout << "The circles created are :" << endl;

    for (iter = circleVector.begin(); iter != circleVector.end(); iter++) {

        cout << iter->toString() << endl;
        //cout<<circleVector[i].toString();
    }

    cout << "The number of circles, using getCount method is " << Circle::getCount() << "\n";
    cout << "The number of circles, using vector size method is " << circleVector.size() << "\n";

    cout << "Erasing the Vector of Circles \n";
    circleVector.erase(circleVector.begin(), circleVector.end());
    
    
    Circle circle(0,0,0);
    cout << "Creating new Circle \n";
    
    cout << "The number of circles, using getCount method is " << Circle::getCount() << "\n";
    cout << "The number of circles remaining is " << circleVector.size() << "\n";

   return 0;
}