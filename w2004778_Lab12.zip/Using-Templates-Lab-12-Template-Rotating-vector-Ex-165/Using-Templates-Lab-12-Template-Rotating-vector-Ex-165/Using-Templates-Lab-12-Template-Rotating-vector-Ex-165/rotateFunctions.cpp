#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

// Function to rotate elements in a vector by one index to the left
template <typename T>
void rotateLeft(vector<T>& v) {
    if (v.empty()) {
        // Handle the case where the vector is empty
        cerr << "Cannot rotate an empty vector." << endl;
        return;
    }

    T temp = v[0]; // Save the first element

    for (size_t i = 1; i < v.size(); ++i) {
        v[i - 1] = v[i]; // Shift elements to the left
    }

    v[v.size() - 1] = temp; // Place the saved element at the end
}

// Function to output elements in a vector with formatting
template <typename T>
void output(const vector<T>& v) {
    for (const T& elem : v) {
        cout << left << setw(10) << setprecision(2) << fixed << elem;
    }
    cout << endl;
}