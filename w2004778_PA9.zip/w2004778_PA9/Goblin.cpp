#include "Goblin.h"
#include "MagicalCreatures.h"




Goblin::Goblin() {}
//default constructor

Goblin::Goblin(std::string name, std::string color, std::string type, int age) : MagicalCreatures(name, color, type, age) {}
//regular constructor inherits the magicalCreatures constructor

std::string Goblin::talk()
{
	std::string value = "I talk gibberish";

	return value;
	//overrides talk function from parent class
}