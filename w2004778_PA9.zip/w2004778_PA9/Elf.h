#ifndef Elf_h
#define Elf_h
#include "MagicalCreatures.h"

//Elf Class
class Elf : public MagicalCreatures
{
private:
	int size;

public:
	Elf();
	//default constructor

	Elf(std::string name, std::string color, std::string type, int age);
	//regular constructor

	std::string toString();
	//overrides toString function from parent class
};
#endif
