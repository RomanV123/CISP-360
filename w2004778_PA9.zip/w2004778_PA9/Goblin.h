#ifndef Goblin_h
#define Goblin_h

#include "MagicalCreatures.h"

//Goblin Class
class Goblin : public MagicalCreatures
{
private:
	bool hasSpikes;
	int size;

public:
	Goblin();
	//default constructor

	Goblin(std::string name, std::string color, std::string type, int age);
	//regular constructor

	std::string talk();
	//overrides talk function from parent class
};

#endif