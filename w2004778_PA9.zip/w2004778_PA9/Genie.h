#ifndef Genie_h
#define Genie_h
#include "MagicalCreatures.h"
class Genie : public MagicalCreatures
{
private:
	bool hasWand;
	int size;

public:
	Genie();
	//default constructor

	Genie(std::string name, std::string color, std::string type, int age, int size, bool hasWand);
	//regular constructor

	int getSize();
	

	bool getHasWand();
	//set to true

	void changeSize(int newSize);
	//big or small

	void setHasWand(bool hasWand);
	

	std::string liveIn();
	
};

#endif