#include "Dragon.h"
#include "MagicalCreatures.h"

Dragon::Dragon() {}
//default constructor

Dragon::Dragon(std::string name, std::string color, std::string type, int age, int size, bool hasSpikes) :MagicalCreatures(name, color, type, age)
{
	this->size = size;
	this->hasSpikes = hasSpikes;
}
//regular constructor

int Dragon::getSize()
{
	return size;
}


bool Dragon::getHasSpike()
{
	return hasSpikes;
}


void Dragon::changeSize(int newSize)
{
	size = newSize;
}


void Dragon::setHasSpike(bool hasSpike)
{
	this->hasSpikes = hasSpike;
}


std::string Dragon::toString()
{
	std::string value = "I am a dragon. I breathe fire!";
	return value;
}
