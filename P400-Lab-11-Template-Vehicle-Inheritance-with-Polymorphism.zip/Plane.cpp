#include "Plane.h"


string Plane::toString(){
    return getType()+ " "+getModel() +" "+ to_string(getYear())+ " Speed "+ to_string(getSpeed());
  }
  